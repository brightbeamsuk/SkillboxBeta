import mg from 'mailgun-js';

export class MailGun {
  send = async (
    from: string,
    to: string,
    subject: string,
    template: string,
    content: any
  ): Promise<any> => {
    const mailgun = new mg({
      apiKey: process.env.MAIL_GUN_API_KEY,
      domain: process.env.MAIL_GUN_DOMAIN,
      host: process.env.MAIL_GUN_API_HOST,
    });
    const data = {
      from: from,
      to: to,
      subject: subject,
      template: template,
      'h:X-Mailgun-Variables': JSON.stringify(content),
      't:text': 'yes',
    };
    try {
      return await mailgun.messages().send(data);
    } catch (error) {
      if (error) {
        return error.message;
      }
    }
  };
}

export default new MailGun();
