import mongoose, { Schema, Document } from 'mongoose';
import { IQuestion } from './../question/model';
export interface IQuizQuestions extends Document {
  question: IQuestion[];
  quiz: 'string';
}

const QuizQuestionsSchema: Schema = new Schema({
  quiz: {
    ref: 'Quiz',
    type: 'ObjectId',
  },
  question: {
    ref: 'Question',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuizQuestions>(
  'QuizQuestions',
  QuizQuestionsSchema
);
