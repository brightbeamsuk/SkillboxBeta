import UploadService from './service';
import { Request, Response } from 'express';
import http from 'http';
export class Controller {
  /**
   * Upload files
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  upload(req: Request, res: Response): void {
    UploadService.upload(req).then((r) => res.json(r));
  }

  base64Image(req: Request, res: Response): void {
    const image_url = req.body.image_url;
    http
      .get(image_url, (resp) => {
        resp.setEncoding('base64');
        let body = 'data:' + resp.headers['content-type'] + ';base64,';
        resp.on('data', (data) => {
          body += data;
        });
        resp.on('end', () => {
          return res.json({ result: body, status: 'success' });
        });
      })
      .on('error', (e) => {
        console.log(`Got error: ${e.message}`);
      });
  }
}

export default new Controller();
