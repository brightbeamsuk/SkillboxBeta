import { CreateQuery } from 'mongoose';
import GroupCourse, { IGroupCourse } from './model';
import L from '../../../common/logger';
export class GroupCourseService {
  async findAll(): Promise<IGroupCourse[]> {
    try {
      return await GroupCourse.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IGroupCourse> {
    try {
      return await GroupCourse.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IGroupCourse>): Promise<IGroupCourse> {
    try {
      return await GroupCourse.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async addMultiple(body: CreateQuery<IGroupCourse>): Promise<IGroupCourse> {
    try {
      return await GroupCourse.insertMany(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IGroupCourse>,
    id: string
  ): Promise<IGroupCourse> {
    try {
      return await GroupCourse.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IGroupCourse> {
    try {
      return await GroupCourse.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await GroupCourse.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await GroupCourse.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new GroupCourseService();
