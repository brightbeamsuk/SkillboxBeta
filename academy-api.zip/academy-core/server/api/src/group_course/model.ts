import mongoose, { Schema, Document } from 'mongoose';
export interface IGroupCourse extends Document {
  course: any;
}

const GroupCourseSchema: Schema = new Schema({
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
  group: {
    ref: 'Group',
    type: 'ObjectId',
  },
});

export default mongoose.model<IGroupCourse>('GroupCourse', GroupCourseSchema);
