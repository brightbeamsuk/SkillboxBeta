import mongoose, { Schema, Document } from 'mongoose';
import { IProfile } from './../profile/model';
import { ISubscription } from './../subscription/model';
export interface IUser extends Document {
  user_name: string;
  password?: string;
  date_created: Date;
  email: string;
  enabled: boolean;
  auth?: boolean;
  token?: string;
  profile?: IProfile;
  subscription?: ISubscription;
}

export interface Auth {
  user_name?: string;
  email?: string;
  password: string;
  new_password?: string;
}

export interface AddUserResponce {
  message: string;
  data: IUser;
}

const UserSchema: Schema = new Schema({
  user_name: {
    type: 'String',
    require: true,
  },
  password: {
    type: 'String',
    require: false,
  },
  date_created: {
    type: 'String',
    require: true,
  },
  email: {
    type: 'String',
    require: true,
  },
  enabled: {
    type: 'Boolean',
    require: true,
  },
});

export default mongoose.model<IUser>('User', UserSchema);
