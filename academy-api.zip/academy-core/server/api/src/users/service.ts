import L from '../../../common/logger';
import User, { IUser } from './model';
import * as crypto from 'crypto';
import { Types } from 'mongoose';
export class UserService {
  async findAll(): Promise<IUser[]> {
    try {
      return await User.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IUser> {
    try {
      if (Types.ObjectId.isValid(id)) {
        return await User.findById(id);
      } else {
        return await User.findOne({ user_name: id });
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(params: IUser): Promise<IUser> {
    L.info(`Signing up new user with username ${params.user_name}`);
    const userName = params.user_name.toString();
    const email = params.email.toString();
    const password = params.password.toString();
    const encryptionKey = process.env.ENCRYPTION_KEY as string;
    const hash = crypto.createHmac('sha512', encryptionKey).update(password);
    const hashedPass = hash.digest('hex').toString();
    try {
      let user: any = '';
      if (userName) {
        user = await User.findOne({ user_name: userName });
      }

      if (email) {
        user = await User.findOne({ email: email });
      }
      if (!user) {
        const dbUserParams = {
          password: hashedPass,
          email: email,
          user_name: userName,
          date_created: Date().toString(),
          enabled: 1,
        };

        const responce = await User.create(dbUserParams);
        if (responce instanceof Error) {
          throw new Error('Error while creating user.');
        }
        return responce;
      } else {
        throw new Error(
          'Username or email address is already associated with an existing account.'
        );
      }
    } catch (error) {
      if (error) {
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IUser> {
    try {
      return await User.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<any> {
    try {
      if (Types.ObjectId.isValid(id)) {
        return await User.findByIdAndDelete(id);
      } else {
        return await User.deleteOne({ user_name: id });
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await User.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await User.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new UserService();
