import { CreateQuery } from 'mongoose';
import CourseActivity, { ICourseActivity } from './model';
import L from '../../../common/logger';
export class CourseActivityService {
  async findAll(): Promise<ICourseActivity[]> {
    try {
      return await CourseActivity.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICourseActivity> {
    try {
      return await CourseActivity.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICourseActivity>): Promise<ICourseActivity> {
    try {
      return await CourseActivity.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<ICourseActivity>,
    id: string
  ): Promise<ICourseActivity> {
    try {
      return await CourseActivity.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICourseActivity> {
    try {
      return await CourseActivity.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await CourseActivity.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await CourseActivity.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CourseActivityService();
