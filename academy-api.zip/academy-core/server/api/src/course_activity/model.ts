import mongoose, { Schema, Document } from 'mongoose';

export interface ICourseActivity extends Document {
  is_started: 'boolean';
  start_date: 'string';
  is_completed: 'boolean';
  completed_date: 'string';
}

const CourseActivitySchema: Schema = new Schema({
  is_started: {
    type: 'Boolean',
    require: true,
  },
  start_date: {
    type: 'String',
    require: true,
  },
  is_completed: {
    type: 'Boolean',
    require: true,
  },
  completed_date: {
    type: 'String',
    require: true,
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICourseActivity>(
  'CourseActivity',
  CourseActivitySchema
);
