import { CreateQuery } from 'mongoose';
import ClientPlanDetails, { IClientPlanDetails } from './model';
import L from '../../../common/logger';
export class ClientPlanDetailsService {
  async findAll(): Promise<IClientPlanDetails[]> {
    try {
      return await ClientPlanDetails.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IClientPlanDetails> {
    try {
      return await ClientPlanDetails.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(
    body: CreateQuery<IClientPlanDetails>
  ): Promise<IClientPlanDetails> {
    try {
      return await ClientPlanDetails.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IClientPlanDetails>,
    id: string
  ): Promise<IClientPlanDetails> {
    try {
      return await ClientPlanDetails.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IClientPlanDetails> {
    try {
      return await ClientPlanDetails.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ClientPlanDetails.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ClientPlanDetails.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ClientPlanDetailsService();
