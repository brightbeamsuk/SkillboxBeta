import mongoose, { Schema, Document } from 'mongoose';

export interface IPaymentGatewaySettings extends Document {
  type: 'string';
  key: 'string';
  secret: 'string';
}

const PaymentGatewaySettingsSchema: Schema = new Schema({
  type: {
    type: 'String',
    require: true,
  },
  key: {
    type: 'String',
    require: true,
  },
  secret: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IPaymentGatewaySettings>(
  'PaymentGatewaySettings',
  PaymentGatewaySettingsSchema
);
