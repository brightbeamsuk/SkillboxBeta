import { CreateQuery } from 'mongoose';
import PaymentGatewaySettings, { IPaymentGatewaySettings } from './model';
import Stripe from 'stripe';
import L from '../../../common/logger';
export class PaymentGatewaySettingsService {
  async findAll(): Promise<IPaymentGatewaySettings[]> {
    try {
      return await PaymentGatewaySettings.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IPaymentGatewaySettings> {
    try {
      return await PaymentGatewaySettings.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async stripeSecret(body: any): Promise<any> {
    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2020-08-27',
      });
      const paymentIntent = await stripe.paymentIntents.create({
        amount: body.amount,
        currency: body.currency,
        metadata: { integration_check: 'accept_a_payment' },
      });
      return { client_secret: paymentIntent.client_secret };
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(
    body: CreateQuery<IPaymentGatewaySettings>
  ): Promise<IPaymentGatewaySettings> {
    try {
      return await PaymentGatewaySettings.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IPaymentGatewaySettings>,
    id: string
  ): Promise<IPaymentGatewaySettings> {
    try {
      return await PaymentGatewaySettings.findByIdAndUpdate(id, body, {
        new: true,
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IPaymentGatewaySettings> {
    try {
      return await PaymentGatewaySettings.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await PaymentGatewaySettings.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await PaymentGatewaySettings.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new PaymentGatewaySettingsService();
