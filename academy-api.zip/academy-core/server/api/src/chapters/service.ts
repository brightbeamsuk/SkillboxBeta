import { CreateQuery } from 'mongoose';
import Chapters, { IChapters } from './model';
import ChaptersRead from './../chapters_read/model';
import Quiz from './../quiz/model';
import QuizQuestions from './../quiz_questions/model';
import Question from './../question/model';
import Options from './../options/model';
import QuizAttemptLog from './../quiz_attempt_log/model';
import QuizAttemptOptions from './../quiz_attempt_options/model';
import L from '../../../common/logger';
export class ChaptersService {
  async findAll(): Promise<IChapters[]> {
    try {
      return await Chapters.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IChapters> {
    try {
      return await Chapters.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async courseChapter(id: string): Promise<IChapters[]> {
    try {
      return await Chapters.find({ course: id });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async candidateCourseChapter(
    courseId: string,
    profileId: string
  ): Promise<IChapters[]> {
    try {
      const chapters = await Chapters.find({ course: courseId });
      for (const chapter of chapters) {
        const chapterRead = await ChaptersRead.findOne({
          profile: profileId,
          course: courseId,
          chapter: chapter._id,
        });
        if (chapterRead) chapter.read = true;
        const quizzes = await Quiz.find({
          course: courseId,
          chapter: chapter._id,
          is_published: true,
        });
        for (const quiz of quizzes) {
          const quizQuestions = await QuizQuestions.find({
            quiz: quiz._id,
          });
          const questions = [];
          for (const question of quizQuestions) {
            const qQuestion = await Question.findById(question.question);
            if (qQuestion) {
              const options = await Options.find({
                question: qQuestion._id,
              });
              qQuestion.options = options;
              const attepmtLog = await QuizAttemptLog.findOne({
                profile: profileId,
                quiz: quiz._id,
                question: qQuestion._id,
              });
              if (attepmtLog) {
                const attemptOptions = await QuizAttemptOptions.find({
                  quiz_attempt_log: attepmtLog._id,
                });
                qQuestion.attemptOption = attemptOptions;
              }
              questions.push(qQuestion);
            }
          }
          quiz.questions = questions;
        }
        if (quizzes.length > 0) chapter.quizzes = quizzes;
      }
      return chapters;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IChapters>): Promise<IChapters> {
    try {
      const chapterCount = await Chapters.countDocuments({
        title: RegExp('^' + body.title + '$', 'i'),
        course: body.course,
      });
      if (chapterCount > 0) throw new Error('Title already exist');
      return await Chapters.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IChapters> {
    try {
      const chapterCount = await Chapters.countDocuments({
        _id: { $ne: id },
        title: RegExp('^' + body.title + '$', 'i'),
        course: body.course,
      });
      if (chapterCount > 0) throw new Error('Title already exist');
      return await Chapters.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IChapters> {
    try {
      return await Chapters.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Chapters.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Chapters.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ChaptersService();
