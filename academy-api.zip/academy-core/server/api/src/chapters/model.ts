import mongoose, { Schema, Document } from 'mongoose';
import { IQuiz } from './../quiz/model';
export interface IChapters extends Document {
  title: 'string';
  content: 'string';
  order: 'number';
  is_assesment: boolean;
  read?: boolean;
  quizzes?: IQuiz[];
  course?: any;
}

const ChaptersSchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  content: {
    type: 'String',
    require: true,
  },
  order: {
    type: 'Number',
    require: true,
  },
  is_assesment: {
    type: 'Boolean',
    require: false,
  },
  read: {
    type: 'Boolean',
    require: false,
  },
  quizzes: {
    type: 'Object',
    require: false,
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<IChapters>('Chapters', ChaptersSchema);
