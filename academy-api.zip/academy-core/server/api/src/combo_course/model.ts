import mongoose, { Schema, Document } from 'mongoose';

export interface IComboCourse extends Document {
  title: 'string';
  description: 'string';
  price: 'number';
  is_published: 'boolean';
}

const ComboCourseSchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  description: {
    type: 'String',
    require: true,
  },
  price: {
    type: 'Number',
    require: true,
  },
  is_published: {
    type: 'Boolean',
    require: true,
  },
});

export default mongoose.model<IComboCourse>('ComboCourse', ComboCourseSchema);
