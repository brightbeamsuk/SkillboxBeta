import { CreateQuery } from 'mongoose';
import ComboCourse, { IComboCourse } from './model';
import L from '../../../common/logger';
export class ComboCourseService {
  async findAll(): Promise<IComboCourse[]> {
    try {
      return await ComboCourse.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IComboCourse> {
    try {
      return await ComboCourse.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IComboCourse>): Promise<IComboCourse> {
    try {
      return await ComboCourse.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IComboCourse>,
    id: string
  ): Promise<IComboCourse> {
    try {
      return await ComboCourse.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IComboCourse> {
    try {
      return await ComboCourse.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ComboCourse.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ComboCourse.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ComboCourseService();
