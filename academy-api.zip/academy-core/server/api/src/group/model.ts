import mongoose, { Schema, Document } from 'mongoose';
import { ICourse } from './../course/model';
export interface IGroup extends Document {
  name: 'string';
  description: 'string';
  total_course?: number;
  client?: any;
  courses?: any;
}

const GroupSchema: Schema = new Schema({
  name: {
    type: 'String',
    require: true,
  },
  total_course: {
    type: 'Number',
    require: false,
  },
  description: {
    type: 'String',
    require: false,
  },
  courses: {
    type: 'Object',
    require: false,
  },
  client: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<IGroup>('Group', GroupSchema);
