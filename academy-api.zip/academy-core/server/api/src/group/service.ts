import { CreateQuery } from 'mongoose';
import Group, { IGroup } from './model';
import GroupCourse, { IGroupCourse } from './../group_course/model';
import Course, { ICourse } from './../course/model';
import CourseEnroll from './../course_enroll/model';
import L from '../../../common/logger';
export class GroupService {
  async findAll(): Promise<IGroup[]> {
    try {
      return await Group.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IGroup> {
    try {
      return await Group.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async byClient(id: string): Promise<IGroup[]> {
    try {
      const groups = await Group.find({ client: id });
      for (const group of groups) {
        const enroll = await GroupCourse.countDocuments({
          group: group._id,
        });
        group.total_course = enroll;
      }
      return groups;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async availableCourse(groupId: string, clientId: string): Promise<ICourse[]> {
    try {
      const groupCourseId = [];
      const clientAssignedCourseId = [];
      const clientAssignedCourses = await CourseEnroll.find({
        profile: clientId,
      });
      for (const assigned of clientAssignedCourses) {
        clientAssignedCourseId.push(assigned.course);
      }

      const groupCourses = await GroupCourse.find({ group: groupId });
      for (const assigned of groupCourses) {
        groupCourseId.push(assigned.course);
      }
      return await Course.find({
        $and: [
          { _id: { $nin: groupCourseId } },
          { _id: { $in: clientAssignedCourseId } },
          { parent_id: '' },
        ],
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async clientGroupCourse(id: string): Promise<IGroup[]> {
    try {
      const groups = await Group.find({ client: id });
      for (const group of groups) {
        const courses = [];
        const groupCourses = await GroupCourse.find({
          group: group._id,
        }).populate('course');
        for (const groupCourse of groupCourses) {
          courses.push(groupCourse.course);
        }
        group.courses = courses;
      }
      return groups;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async groupCourse(id: string): Promise<IGroupCourse[]> {
    try {
      return await GroupCourse.find({ group: id }).populate('course');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IGroup>): Promise<IGroup> {
    try {
      const groupCount = await Group.countDocuments({
        name: RegExp('^' + body.name + '$', 'i'),
        client: body.client,
      });
      console.log('groupCount', groupCount);
      if (groupCount > 0) throw new Error('Title already exist');
      return await Group.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IGroup> {
    try {
      const groupCount = await Group.countDocuments({
        _id: { $ne: id },
        name: RegExp('^' + body.name + '$', 'i'),
        client: body.client,
      });
      if (groupCount > 0) throw new Error('Title already exist');
      return await Group.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IGroup> {
    try {
      return await Group.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Group.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Group.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new GroupService();
