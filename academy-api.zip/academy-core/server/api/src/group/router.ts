import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/by_client/:client_id', tokenVerify, controller.byClient)
  .get(
    '/available_course/:group_id/:client_id',
    tokenVerify,
    controller.availableCourse
  )
  .get(
    '/client/group_course/:client_id',
    tokenVerify,
    controller.clientGroupCourse
  )
  .get('/group_course/:group_id', tokenVerify, controller.groupCourse)
  .post('/', tokenVerify, controller.store)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
