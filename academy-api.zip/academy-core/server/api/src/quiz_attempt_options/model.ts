import mongoose, { Schema, Document } from 'mongoose';

export type IQuizAttemptOptions = Document;

const QuizAttemptOptionsSchema: Schema = new Schema({
  quiz_attempt_log: {
    ref: 'QuizAttemptLog',
    type: 'ObjectId',
  },
  option: {
    ref: 'Options',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuizAttemptOptions>(
  'QuizAttemptOptions',
  QuizAttemptOptionsSchema
);
