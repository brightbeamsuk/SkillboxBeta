import { CreateQuery } from 'mongoose';
import QuizAttemptOptions, { IQuizAttemptOptions } from './model';
import L from '../../../common/logger';
export class QuizAttemptOptionsService {
  async findAll(): Promise<IQuizAttemptOptions[]> {
    try {
      return await QuizAttemptOptions.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IQuizAttemptOptions> {
    try {
      return await QuizAttemptOptions.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(
    body: CreateQuery<IQuizAttemptOptions>
  ): Promise<IQuizAttemptOptions> {
    try {
      return await QuizAttemptOptions.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IQuizAttemptOptions>,
    id: string
  ): Promise<IQuizAttemptOptions> {
    try {
      return await QuizAttemptOptions.findByIdAndUpdate(id, body, {
        new: true,
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IQuizAttemptOptions> {
    try {
      return await QuizAttemptOptions.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await QuizAttemptOptions.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await QuizAttemptOptions.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new QuizAttemptOptionsService();
