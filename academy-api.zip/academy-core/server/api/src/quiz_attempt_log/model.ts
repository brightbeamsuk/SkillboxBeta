import mongoose, { Schema, Document } from 'mongoose';

export type IQuizAttemptLog = Document;

const QuizAttemptLogSchema: Schema = new Schema({
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  quiz: {
    ref: 'Quiz',
    type: 'ObjectId',
  },
  question: {
    ref: 'Question',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuizAttemptLog>(
  'QuizAttemptLog',
  QuizAttemptLogSchema
);
