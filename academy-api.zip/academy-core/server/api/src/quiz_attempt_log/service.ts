import { CreateQuery } from 'mongoose';
import QuizAttemptLog, { IQuizAttemptLog } from './model';
import QuizAttemptOptions from './../quiz_attempt_options/model';
import QuestionAnswers from './../question_answers/model';
import Question from './../question/model';
import QuizAttempt from './../quiz_attempt/model';
import QuizQuestion from './../quiz_questions/model';
import ChapterRead from './../chapters_read/model';

import L from '../../../common/logger';
export class QuizAttemptLogService {
  async findAll(): Promise<IQuizAttemptLog[]> {
    try {
      return await QuizAttemptLog.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IQuizAttemptLog> {
    try {
      return await QuizAttemptLog.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IQuizAttemptLog>): Promise<IQuizAttemptLog> {
    try {
      return await QuizAttemptLog.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async saveCandidateAnswers(body: any): Promise<IQuizAttemptLog> {
    try {
      let attempt = await QuizAttempt.findOne({
        quiz: body.quiz,
        profile: body.profile,
        status: 'InProgress',
      });
      if (!attempt) {
        attempt = await QuizAttempt.create({
          quiz: body.quiz,
          profile: body.profile,
          status: 'InProgress',
          mark: 0,
          correct: 0,
          wrong: 0,
        });
      }
      await QuizAttemptLog.deleteMany({
        profile: body.profile,
        quiz: body.quiz,
        question: body.question,
      });
      const newData = await QuizAttemptLog.create({
        profile: body.profile,
        quiz: body.quiz,
        question: body.question,
      });
      for (const data of body.answers) {
        await QuizAttemptOptions.create({
          quiz_attempt_log: newData._id,
          option: data.option,
        });
      }
      return newData;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async validateAnswers(body: any, quizId: any, profileId: any): Promise<any> {
    try {
      let attempt = await QuizAttempt.findOne({
        quiz: quizId,
        profile: profileId,
      }).sort({ _id: -1 });
      const totalQuestion = await QuizQuestion.countDocuments({ quiz: quizId });
      const output = [];
      let mark = 0;
      let correct = 0;
      let wrong = 0;
      console.log('totalQuestion', totalQuestion);
      for (const question of body.questions) {
        const questionId = question.question;
        const answers = question.answers;
        const qQuestion = await Question.findById(questionId);
        let qAnwers;
        if (qQuestion.type === 'Single Choice') {
          qAnwers = await QuestionAnswers.findOne({ question: questionId });
        } else {
          qAnwers = await QuestionAnswers.find({ question: questionId });
        }
        const responce = { question: questionId, answers: [] };

        if (qQuestion.type === 'Single Choice') {
          if (answers[0].option == qAnwers.option) {
            responce.answers.push({ option: qAnwers.option, correct: true });
            mark++;
            correct++;
          } else {
            responce.answers.push({ option: qAnwers.option, correct: false });
            wrong++;
          }
        } else {
          const ans = [];
          let MCMark = 0;
          for (const qAnwer of qAnwers) {
            const res = answers.filter((a) => a.option == qAnwer.option);
            if (res.length > 0) {
              ans.push({ option: qAnwer.option, correct: true });
              MCMark++;
              correct++;
            } else {
              ans.push({ option: qAnwer.option, correct: false });
              wrong++;
            }
          }
          mark = mark + MCMark / qAnwers.length;
          responce.answers = ans;
        }
        output.push(responce);
      }
      if (attempt) {
        attempt.mark = (mark / totalQuestion) * 100;
        attempt.correct = correct;
        attempt.wrong = wrong;
        attempt.status = 'Completed';
        attempt = await QuizAttempt.findByIdAndUpdate(attempt._id, attempt, {
          new: true,
        });
      }
      return { output, attempt };
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async reAttemptQuiz(body: any): Promise<any> {
    try {
      await QuizAttemptLog.deleteMany({
        profile: body.profileId,
        quiz: body.quizId,
      });
      await ChapterRead.deleteOne({
        profile: body.profileId,
        chapter: body.chapterId,
      });
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IQuizAttemptLog>,
    id: string
  ): Promise<IQuizAttemptLog> {
    try {
      return await QuizAttemptLog.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IQuizAttemptLog> {
    try {
      return await QuizAttemptLog.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await QuizAttemptLog.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await QuizAttemptLog.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new QuizAttemptLogService();
