import mongoose, { Schema, Document } from 'mongoose';

export interface ICourseEnroll extends Document {
  enrolled_date: 'date';
  expiry_date: 'date';
  subscription?: string;
  started: boolean;
  completed: boolean;
  course: any;
  profile: any;
}

const CourseEnrollSchema: Schema = new Schema({
  enrolled_date: {
    type: 'Date',
    require: true,
  },
  expiry_date: {
    type: 'Date',
    require: false,
  },
  started: {
    type: 'Boolean',
    require: false,
  },
  completed: {
    type: 'Boolean',
    require: false,
  },
  subscription: {
    type: 'String',
    require: false,
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICourseEnroll>(
  'CourseEnroll',
  CourseEnrollSchema
);
