import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .post('/', tokenVerify, controller.store)
  .post('/multiple', tokenVerify, controller.addMultiple)
  .get('/course/assigned/:profile_id', tokenVerify, controller.assignedCourse)
  .get('/course/my-course/:profile_id', tokenVerify, controller.myCourse)
  .get(
    '/course/un-assigned/:profile_id',
    tokenVerify,
    controller.unAssignedCourse
  )
  .get(
    '/candidate/course/un-assigned/:client_id/:profile_id',
    tokenVerify,
    controller.candidateUnAssignedCourse
  )
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
