import { CreateQuery } from 'mongoose';
import CourseEnroll, { ICourseEnroll } from './model';
import Course, { ICourse } from './../course/model';
import CourseCategory from './../course_category/model';
import Chapters from './../chapters/model';
import ChaptersRead from './../chapters_read/model';
import L from '../../../common/logger';
import Profile from '../profile/model';
import ClientUser from '../client_users/model';
export class CourseEnrollService {
  async findAll(): Promise<ICourseEnroll[]> {
    try {
      return await CourseEnroll.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICourseEnroll> {
    try {
      return await CourseEnroll.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async assignedCourse(profileId: string): Promise<ICourseEnroll[]> {
    try {
      const profile = await Profile.findById(profileId).populate(
        'profile_type'
      );
      let pId = profileId;
      if (profile.profile_type.slug === 'system_users') {
        const clientProfile = await ClientUser.findOne({
          profile: profileId,
        });
        pId = clientProfile.client_profile;
      }
      const courses = await CourseEnroll.find({ profile: pId })
        .populate('course')
        .populate('category');
      for (const course of courses) {
        course.course.total_chapter = await Chapters.countDocuments({
          course: course.course._id,
        });
        const chapterReadCount = await ChaptersRead.countDocuments({
          course: course.course._id,
        });
        course.course.total_chapter_read = chapterReadCount;
        course.course.completed =
          (chapterReadCount / course.course.total_chapter) * 100;
      }
      return courses;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async myCourse(profileId: string): Promise<ICourse[]> {
    try {
      const enrolls = await CourseEnroll.find({
        profile: profileId,
      });
      const myCourses = [];
      for (const enroll of enrolls) {
        const course = await Course.findOne({
          _id: enroll.course,
          published: true,
        }).populate('category');
        if (course) {
          course.total_chapter = await Chapters.countDocuments({
            course: course._id,
          });
          const chapterReadCount = await ChaptersRead.countDocuments({
            course: course._id,
            profile: profileId,
          });
          course.total_chapter_read = chapterReadCount;
          course.completed = (chapterReadCount / course.total_chapter) * 100;
          course.course_completed = enroll.completed ? true : false;
          myCourses.push(course);
        }
      }
      return myCourses;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async unAssignedCourse(profileId: string): Promise<ICourse[]> {
    try {
      const profile = await Profile.findById(profileId).populate(
        'profile_type'
      );
      let pId = profileId;
      if (profile.profile_type.slug === 'system_users') {
        const clientProfile = await ClientUser.findOne({
          profile: profileId,
        });
        pId = clientProfile.client_profile;
      }
      const assignedCourseId = [];
      const assignedCourses = await CourseEnroll.find({ profile: pId });
      for (const assigned of assignedCourses) {
        assignedCourseId.push(assigned.course);
      }
      return await Course.find({
        _id: { $nin: assignedCourseId },
        parent_id: '',
        published: true,
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async candidateUnAssignedCourse(
    clientId: string,
    profileId: string
  ): Promise<ICourse[]> {
    try {
      const candidateAssignedCourseId = [];
      const clientAssignedCourseId = [];
      const profile = await Profile.findById(clientId).populate('profile_type');
      let cId = clientId;
      if (profile.profile_type.slug === 'system_users') {
        const clientProfile = await ClientUser.findOne({
          profile: profileId,
        });
        cId = clientProfile.client_profile;
      }
      if (profileId !== 'null') {
        const candidateAssignedCourses = await CourseEnroll.find({
          profile: profileId,
        });
        for (const assigned of candidateAssignedCourses) {
          candidateAssignedCourseId.push(assigned.course);
        }
      }
      const clientAssignedCourses = await CourseEnroll.find({
        profile: cId,
      });
      for (const assigned of clientAssignedCourses) {
        clientAssignedCourseId.push(assigned.course);
      }
      return await Course.find({
        $and: [
          { _id: { $nin: candidateAssignedCourseId } },
          { _id: { $in: clientAssignedCourseId } },
          { parent_id: '' },
        ],
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICourseEnroll>): Promise<ICourseEnroll> {
    try {
      return await CourseEnroll.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async addMultiple(body: any): Promise<boolean> {
    try {
      const datas = body;
      for (const data of datas) {
        const oldEnroll = await CourseEnroll.findOne({
          course: data.course,
          profile: data.profile,
        });
        if (!oldEnroll) {
          await CourseEnroll.create(body);
        }
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<ICourseEnroll> {
    try {
      return await CourseEnroll.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICourseEnroll> {
    try {
      return await CourseEnroll.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await CourseEnroll.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await CourseEnroll.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CourseEnrollService();
