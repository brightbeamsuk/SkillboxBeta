import CourseEnrollService from './service';
import { Request, Response } from 'express';
export class Controller {
  /**
   * List all records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  index(req: Request, res: Response): void {
    CourseEnrollService.findAll().then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  show(req: Request, res: Response): void {
    const id = req.params['id'];
    CourseEnrollService.findById(id).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  assignedCourse(req: Request, res: Response): void {
    const profileId = req.params['profile_id'];
    CourseEnrollService.assignedCourse(profileId).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  myCourse(req: Request, res: Response): void {
    const profileId = req.params['profile_id'];
    CourseEnrollService.myCourse(profileId).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  unAssignedCourse(req: Request, res: Response): void {
    const profileId = req.params['profile_id'];
    CourseEnrollService.unAssignedCourse(profileId).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  candidateUnAssignedCourse(req: Request, res: Response): void {
    const profileId = req.params['profile_id'];
    const clientId = req.params['client_id'];
    CourseEnrollService.candidateUnAssignedCourse(
      clientId,
      profileId
    ).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  store(req: Request, res: Response): void {
    const body = req.body;
    CourseEnrollService.create(body).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  addMultiple(req: Request, res: Response): void {
    const body = req.body;
    CourseEnrollService.addMultiple(body).then((r) => res.json(r));
  }

  /**
   * Update record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  update(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['id'];
    CourseEnrollService.update(body, id).then((r) => res.json(r));
  }

  /**
   * Delete record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  delete(req: Request, res: Response): void {
    const id = req.params['id'];
    CourseEnrollService.deleteById(id).then((r) => res.json(r));
  }

  /**
   * Delete all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  deleteAll(req: Request, res: Response): void {
    CourseEnrollService.deleteAll().then((r) => res.json(r));
  }

  /**
   * Count all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  count(req: Request, res: Response): void {
    CourseEnrollService.count().then((r) => res.json(r));
  }
}

export default new Controller();
