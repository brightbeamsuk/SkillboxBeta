import AuthService from './service';
import { Request, Response } from 'express';

export class Controller {
  mockData(req: Request, res: Response): void {
    AuthService.mockData().then((r) => res.status(201).json(r));
  }

  login(req: Request, res: Response): void {
    AuthService.login(req.body).then((r) => res.status(201).json(r));
  }

  changePassword(req: Request, res: Response): void {
    AuthService.changePassword(req.body).then((r) => res.status(201).json(r));
  }

  generateJWT(req: Request, res: Response): void {
    const userId = req.query.user_id as string;
    const email = req.query.email as string;
    AuthService.generateJWT(userId, email).then((r) => res.status(201).json(r));
  }

  /**
   * Forgot Password
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  forgotPassword(req: Request, res: Response): void {
    const body = req.body;
    AuthService.forgotPassword(body).then((r) => res.json(r));
  }
}
export default new Controller();
