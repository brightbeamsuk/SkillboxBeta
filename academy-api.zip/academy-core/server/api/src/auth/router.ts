import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';

export default express
  .Router()
  .get('/mock_data', controller.mockData)
  .post('/login', controller.login)
  .post('/change-password', tokenVerify, controller.changePassword)
  .post('/generate/jwt', controller.generateJWT)
  .post('/forgot_password', controller.forgotPassword);
