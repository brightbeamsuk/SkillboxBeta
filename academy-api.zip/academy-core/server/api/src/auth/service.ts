import L from '../../../common/logger';
import User, { IUser, Auth } from '../users/model';
import ProfileService from '../profile/service';
import ProfileType from '../profile_type/model';
import Subscription from '../subscription/model';
import ClientUser from '../client_users/model';
import Profile from '../profile/model';
import MailGun from '../../../common/email/mail.gun';

import * as crypto from 'crypto';
import jwt from 'jsonwebtoken';

export class AuthService {
  async mockData(): Promise<any> {
    try {
      const user = await User.findOne({ user_name: 'admin' });
      if (user) {
        throw new Error('Mock script executed already');
      }
      const password = 'AdmAca454';
      const encryptionKey = process.env.ENCRYPTION_KEY as string;
      const hash = crypto.createHmac('sha512', encryptionKey).update(password);
      const hashedPass = hash.digest('hex').toString();
      const responce = await User.create({
        user_name: 'admin',
        email: 'admin@logezyacademy.com',
        password: hashedPass,
        date_created: Date().toString(),
        enabled: 1,
      });
      const agency = await ProfileType.create({
        name: 'Agency',
        slug: 'agency',
      });
      await ProfileType.create({ name: 'Client', slug: 'client' });
      await ProfileType.create({ name: 'Candidate', slug: 'candidate' });
      await ProfileType.create({ name: 'System Users', slug: 'system_users' });

      await Profile.create({
        first_name: 'Logezy',
        last_name: 'Academy',
        email: 'admin@logezyacademy.com',
        phone: '999999999',
        profile_image: '',
        client_logo: '',
        client_name: '',
        certificate_access: true,
        is_active: true,
        status: 'active',
        created_by: responce._id,
        profile_type: agency._id,
        user: responce._id,
      });
      return { status: 200, message: 'Mock script added successfully' };
    } catch (error) {
      if (error) {
        return error.message;
      }
    }
  }
  async login(params: Auth): Promise<any> {
    const userName = params.user_name;
    const email = params.email;
    const password = params.password.toString();
    const encryptionKey = process.env.ENCRYPTION_KEY as string;
    const hash = crypto.createHmac('sha512', encryptionKey).update(password);
    const UserHashedPass = hash.digest('hex').toString();
    try {
      let user: any = '';
      if (userName) {
        const uName = new RegExp(['^', userName, '$'].join(''), 'i');
        user = await User.findOne({ user_name: uName });
      }

      if (email) {
        const uEmail = new RegExp(['^', email, '$'].join(''), 'i');
        user = await User.findOne({ email: uEmail });
      }

      if (user instanceof Error) {
        throw new Error('Something went wrong');
      }

      if (!user) {
        throw new Error('User not exist.');
      }

      if (!user.enabled) {
        throw new Error('User disabled please contact administrator');
      }

      if (user.password !== UserHashedPass) {
        throw new Error('Invalid username or password');
      }

      const token = jwt.sign(user.toJSON(), encryptionKey, {});
      const profile = await ProfileService.getProfileByUserId(user._id);
      let subscription;
      let clientId;
      let clientLogo = process.env.CLIENT_LOGO;
      if (profile) {
        subscription = await Subscription.find({ profile: profile._id })
          .sort({ _id: -1 })
          .limit(1);
        if (profile.profile_type.slug === 'client') {
          clientLogo = profile.client_logo;
        }
        if (profile.profile_type.slug === 'candidate') {
          const clientProfile = await ClientUser.findOne({
            profile: profile._id,
          }).populate('client_profile');
          if (clientProfile && clientProfile.client_profile) {
            clientLogo = clientProfile.client_profile.client_logo;
          }
        }
        if (profile.profile_type.slug === 'system_users') {
          const clientProfile = await ClientUser.findOne({
            profile: profile._id,
          }).populate('client_profile');
          if (clientProfile && clientProfile.client_profile) {
            clientLogo = clientProfile.client_profile.client_logo;
            clientId = clientProfile.client_profile._id;
            subscription = await Subscription.find({ profile: clientId })
              .sort({ _id: -1 })
              .limit(1);
          }
        }
      }
      return {
        ...user._doc,
        token,
        profile,
        subscription,
        auth: true,
        clientLogo,
        clientId,
      };
    } catch (error) {
      if (error) {
        return error.message;
      }
    }
  }

  async changePassword(params: Auth): Promise<any> {
    const userName = params.user_name;
    const email = params.email;
    const password = params.password.toString();
    const npassword = params.new_password.toString();
    const encryptionKey = process.env.ENCRYPTION_KEY as string;
    const hash = crypto.createHmac('sha512', encryptionKey).update(password);
    const UserHashedPass = hash.digest('hex').toString();
    const nhash = crypto.createHmac('sha512', encryptionKey).update(npassword);
    const NewHashedPass = nhash.digest('hex').toString();
    try {
      let user: any = '';
      if (userName) {
        user = await User.findOne({ user_name: userName });
      }

      if (email) {
        user = await User.findOne({ email: email });
      }

      if (!user) {
        throw new Error('User not exist.');
      }
      if (user instanceof Error) {
        throw new Error('Something went wrong');
      }

      if (user.password !== UserHashedPass) {
        throw new Error('Old password is invalid');
      }

      return User.findByIdAndUpdate(user._id, {
        user_name: user.email,
        password: NewHashedPass,
      });
    } catch (error) {
      if (error) {
        return error.message;
      }
    }
  }

  async forgotPassword(body: any): Promise<boolean> {
    try {
      const profile = await Profile.findOne({ email: body.email });
      if (!profile) {
        throw new Error('Your email id not exist in our system.');
      }
      const password =
        profile.first_name.substring(0, 3) +
        profile.last_name.substring(0, 3) +
        Math.floor(Math.random() * (999 - 100 + 1) + 100);
      const encryptionKey = process.env.ENCRYPTION_KEY as string;
      const hash = crypto.createHmac('sha512', encryptionKey).update(password);
      const hashedPass = hash.digest('hex').toString();
      await User.findByIdAndUpdate(profile.user, {
        user_name: profile.email,
        password: hashedPass,
      });
      const from = `${process.env.MAIL_GUN_FROM_NAME} <${process.env.MAIL_GUN_FROM_EMAIL}>`;
      const content = {
        user_name: profile.email,
        password: password,
        full_name: profile.first_name + ' ' + profile.last_name,
      };
      const subject = 'Forgot Password Credential';
      const templateId = 'forgot-password';
      const to = profile.email;
      await MailGun.send(from, to, subject, templateId, content);
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async generateJWT(userId: string, email: string): Promise<any> {
    const payload = {
      sub: userId, // Unique user id string
      name: email,
      exp: Math.floor(Date.now() / 1000) + 60 * 10, // 10 minutes expiration
    };
    const privateKey = `
-----BEGIN PRIVATE KEY-----
MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQCWUzmBI5zGcriA
9Fj+XpukNDXu6k8nb1sFxv8EU3f+mdCbPHoAnTJHFjEKs8H+q6iXUtG486WqaS8s
EaW2X4FwmoH6ng0RsUxkgWhL8HG05lkFbmSNDClIp9BGSIoqnTSI4U6uvxE0Ywx4
IycEFWjwTTeIv9nE0GTgbhvPXsd1aZSHqNAv+ceL7SRMvbFB0OZvfp1IMS3qzaZs
jH2HexybtBMslDiHzwXU1rlPbjwbdPStxjaNmqEhwPmbyJlU4l9Nm7nPYxckIzxf
UL0LiSbPfa9WrhkazDR3jFuPJeyuPT2sFupc+1q5XtYztQOx4tZPjhfO6qNVkHOW
CjaScrmU9VUUV1u52/aLCAmc4GEcLxxp3cn567W2k8nFYOpz2IXIK19ZLms2DrIM
YcamTBFJskKFg9YeygbbiJLuqzdk6vOjk6GPl3ibxF8IUicU1e/3i7rYvNNZuXQC
fTBdY525DYQVyCCau7DrpmV+Dsplf+ukAEDYxyyMaxoK0cE13AKBxZyBf5RDdEtR
J4nxwO6AxFXL5RGhHZ26R/WxQlve8tiLVF3W3rRGmBPzBHDoZWXKfLtRU3NQDvkY
nozfZm6GBaxgN0QnZXE7zyFvVtS3qk1QBaqDsSFeDy/57ZcWuFXj13s157SsYZJM
AHXK1OeSGx75NkRdI/araR3fvFbqrQIDAQABAoICAEB1vo5UPYlRLzHI1ZJ58iam
5sukuL1xwCfJjZgGzMklnvC6LZyuy5z09KGgtFqmtDvzXRAAlnTs9rfgd10tNf2Z
m4vikzsXemkMnrMVj0Shk+HC1SYwZVGM+D/zIiAk2h6p8on3T4LVyEaJ2FSlc6K7
kck3b0O4ktE0FgPFoiUEWZcUefVgl8M2NJ8dpnFRCUcdFYeb4xMxDSC126wpS/qu
bJxskJMX4GnEi6D2ZZrme3c6rDDrchXdwIsfKTTffztxv+sglA9AdsZugin8rWJD
BFlYfVZi40qyKp7HBecvRo9RIj0t4VjkxFhW0hdI7Fof1bC6J8DsmMvpZD5HKLGB
gFe/RVdqFQqyCHDkLKX0EXzkan7rLk2mlsO0We2gVVTuLYzSYqnryrmt6yPZlGfp
1UeFXwednNCAmdGAHzuylU0zaiy3ArU9Eef39EACPe4j8s5prOHgcyj8TL7WVQjE
GRSG6tcHy2F+rpXmoH4cU8vXMavm+Ghg004vx/tJAE65X0/RMZw82/E/0cWmVnUZ
QKvob/S5CLMfFuxRgqxRAR1hqWFdpicO+Pr+WYiXNmcT9QyVc6Xahr+MGSg+lD0O
NaLhPECZOkeDRmP+HRoX0HFyMA8atzk+92i52O0TjnP7qIJH1XM4uWHKdrVqS5Ao
ax6T6BMoBQvcgMGLZWfnAoIBAQDHemXnjDi+PgAOiqr0XHX5wFaNrwGpC7x38RPE
FKuCtr5vOq8fIhO0TUF/5CGNPaX1YDeCD9k8+yfi+6vGIzfw7YsWlM7eOY3bJYjA
iT+Hj60ZU6sflmoZODSBejloWD0SmHVNi7u9e/nGXNf6ziOuMdYNSDGPAMNUSVaY
l82ODgbmHORWZJs8n1mFofu5FZxBBGxx6bFkYRTzTCa6XdlzJ/xiM55XVvXTVx9u
KCWXmueu6ZEtTcxPVHPShuyPxPXnGNLkfjqx/kqhqtqXXZHUcDpC3zNbVRDBB57l
YOKLu3cBfGhymRkCq0lmAw+NmMM1++iUdsnaxpAgDmqZ5sqHAoIBAQDA62ZOfwwn
veIQvNAcZyiIGz97MuuQj9o5+hh/up9tMqJrWeVN0pW1DNvR97WZA+8I7INkT8VP
f3k0nvQPyopld0da3Orod1XOKK+1lDIZqh2HbHjZjdB5ESLiXeG+3hAp0Uybi6Xu
B3VaJDfJjEkQHPXA0ZvlHxHsDbSqEEA8ipRyRBq0G1pFsIxkldIltQ1FhDh99OF2
ddj6n5upicIlYO27gWczeZEW8QPkSxNHk974XA4q2qLg9v0NIbBAGub6pY+MFscP
h26HTCor0U/UvP6P9oyn49UKMdm6tztJ9oDy3jRqIO+k1vawgcEV+I9NPz2fqTD+
UKRsjx9SUWorAoIBAEtZFXMACVL68mSLxoVlA38iQs9j4pmrADbCDjhLonlOc+Jp
5Uo6Qf0iDXK0hmPmfHCSNoVfXSxmpitb6wd9uBy+bYJLFVTlooq7w8sOTLv07mqZ
qxLUayE5lMOvmk2qvu7uPajb9j9du/xMh5yKDvo2gucjdOzSWfXVeetLs+5LqBl1
ol5rxCODAXqzs/S2j/4TIK9qmYIUFajNA/fziTaxTOj/HHlbNKHuz8V5TrHUZl0w
hpD5SQpSGSnVozevKz9upgJ/F8ayChjFA6qXQoVfGvK1gp2mJRz0tvVnwksLtakP
CBj5cXQLpT7uOwq+QEZ8795cfGSyCjDBoUye27MCggEBAJ7XMv0ejhuKtD+jtpYs
OasXBEWjv2DfkIZ77P/94JZAQoqxEaPp52mSlMtkcRjzrDRkyConpAW4p0s0NS9r
TFgOxamCi8erufJsfX+77SREdNuz7Cz0HtoPyfEn618D57sGoVTQvmYlrfHyMBy6
bM3filigPQOBeXgqML51cu5mC6Opf3Mbsk/+9Rk8YjK5x5udKgZLQfgPP//auof0
7O1pyVPBT/+J8HQ7LUEir1UX41YKNYADVGh19BSD0GJ3xAZLms11U6DtmYu8olxB
ksFOeyp9jYIOjLJAKU0a4K4dUD6nxfA7/hRzCdp6e0hjx1mK4Go9HCHItBjOHrPg
ZNECggEBALH6XAx1j5HvLbVi7p4QbmCwXZZZqXFpIB1U0UhM0qNZEFHwmxc0XWzF
pYmrpMVOtqhX74eZhRs6g6arDdhMa9PGwhA1qgwve59WycBDo2bRh05L2r8w3rHx
XbKTJMK72fSzkEGuO7fOmNXTn1V2Ie3b2tpM/JmsF8WMjEJOqkNs3GsTo2z4RXVM
ZeTPp9HhvmI8UAhpfKP/dSozEh7+BcA50RjODyicwxcKCCPT0x64nBueuqMK8pdl
1Yk3+kIGhnj7wDLlpqIfvtLwHsh6rTIe0+zPnvu/oNwaN6qyneLh1fqetI/NwFZs
RA2ZrDShmE9L94KCrKiDUdRMayKhzDY=
-----END PRIVATE KEY-----`;
    try {
      const token = jwt.sign(payload, privateKey, { algorithm: 'RS256' });
      return { token };
    } catch (e) {
      if (e) {
        return e.message;
      }
    }
  }
}

export default new AuthService();
