import mongoose, { Schema, Document } from 'mongoose';
import { IPlanDetails } from './../plan_details/model';

export interface IPlans extends Document {
  title: 'string';
  description: 'string';
  type: 'string';
  details: IPlanDetails[];
}

const PlansSchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  description: {
    type: 'String',
    require: true,
  },
  details: {
    type: 'Object',
    require: false,
  },
  type: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IPlans>('Plans', PlansSchema);
