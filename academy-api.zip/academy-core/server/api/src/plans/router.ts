import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/client/:client_id', tokenVerify, controller.getClientPlans)
  .post('/', tokenVerify, controller.store)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
