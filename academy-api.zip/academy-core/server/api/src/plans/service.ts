import { CreateQuery } from 'mongoose';
import Plans, { IPlans } from './model';
import PlanDetails from './../plan_details/model';
import ClientPlanDetails from './../client_plan_details/model';
import L from '../../../common/logger';
export class PlansService {
  async findAll(): Promise<IPlans[]> {
    try {
      const plans = await Plans.find();
      for (const plan of plans) {
        plan.details = await PlanDetails.find({ plan: plan._id });
      }
      return plans;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IPlans> {
    try {
      const plan = await Plans.findById(id);
      plan.details = await PlanDetails.find({ plan: plan._id });
      return plan;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getClientPlans(clientId: string): Promise<IPlans[]> {
    try {
      const plans = await Plans.find();
      for (const plan of plans) {
        plan.details = await ClientPlanDetails.find({
          plan: plan._id,
          profile: clientId,
        });
      }
      return plans;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IPlans>): Promise<IPlans> {
    try {
      return await Plans.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IPlans> {
    try {
      return await Plans.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IPlans> {
    try {
      return await Plans.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Plans.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Plans.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new PlansService();
