import { CreateQuery } from 'mongoose';
import EmailTemplates, { IEmailTemplates } from './model';
import L from '../../../common/logger';
export class EmailTemplatesService {
  async findAll(): Promise<IEmailTemplates[]> {
    try {
      return await EmailTemplates.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IEmailTemplates> {
    try {
      return await EmailTemplates.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findBySlug(clientId: string, slug: string): Promise<IEmailTemplates> {
    try {
      return await EmailTemplates.findOne({ client: clientId, slug });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IEmailTemplates>): Promise<IEmailTemplates> {
    try {
      return await EmailTemplates.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createEmailTemplate(clientId: string): Promise<boolean> {
    try {
      await EmailTemplates.create({
        subject: 'Course Completed',
        body:
          '<p style="box-sizing: border-box; margin: 0px; cursor: text; padding: 0px; counter-reset: list-1 0 list-2 0 list-3 0 list-4 0 list-5 0 list-6 0 list-7 0 list-8 0 list-9 0; color: #001737; font-family: Helvetica, Arial, sans-serif; font-size: 16px; white-space: pre-wrap;">This [candidate_name], has completed [course_name] with score of [grade].</p>\n<p style="box-sizing: border-box; margin: 0px; cursor: text; padding: 0px; counter-reset: list-1 0 list-2 0 list-3 0 list-4 0 list-5 0 list-6 0 list-7 0 list-8 0 list-9 0; color: #001737; font-family: Helvetica, Arial, sans-serif; font-size: 16px; white-space: pre-wrap;">&nbsp;</p>\n<p style="box-sizing: border-box; margin: 0px; cursor: text; padding: 0px; counter-reset: list-1 0 list-2 0 list-3 0 list-4 0 list-5 0 list-6 0 list-7 0 list-8 0 list-9 0; color: #001737; font-family: Helvetica, Arial, sans-serif; font-size: 16px; white-space: pre-wrap;">Thank you.</p>\n<p style="box-sizing: border-box; margin: 0px; cursor: text; padding: 0px; counter-reset: list-1 0 list-2 0 list-3 0 list-4 0 list-5 0 list-6 0 list-7 0 list-8 0 list-9 0; color: #001737; font-family: Helvetica, Arial, sans-serif; font-size: 16px; white-space: pre-wrap;">&nbsp;</p>',
        receipients: '',
        is_enabled: true,
        slug: 'course-complete',
        client: clientId,
      });
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: CreateQuery<IEmailTemplates>, id: string): Promise<IEmailTemplates> {
    try {
      return await EmailTemplates.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IEmailTemplates> {
    try {
      return await EmailTemplates.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await EmailTemplates.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await EmailTemplates.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new EmailTemplatesService();
