import mongoose, { Schema, Document } from 'mongoose';

export interface IEmailTemplates extends Document {
  subject: string;
  body: string;
  receipients: string;
  is_enabled: 'boolean';
  slug: string;
}

const EmailTemplatesSchema: Schema = new Schema({
  subject: {
    type: 'String',
    require: true,
  },
  body: {
    type: 'String',
    require: true,
  },
  receipients: {
    type: 'String',
    require: false,
  },
  is_enabled: {
    type: 'Boolean',
    require: true,
  },
  client: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  slug: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IEmailTemplates>(
  'EmailTemplates',
  EmailTemplatesSchema
);
