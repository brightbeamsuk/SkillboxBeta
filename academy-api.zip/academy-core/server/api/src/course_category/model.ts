import mongoose, { Schema, Document } from 'mongoose';

export interface ICourseCategory extends Document {
  title: string;
  description: string;
  image: string;
  parent_id: string;
  child: any;
}

const CourseCategorySchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  description: {
    type: 'String',
    require: true,
  },
  image: {
    type: 'String',
    require: true,
  },
  parent_id: {
    type: 'String',
    require: true,
  },
  child: {
    type: 'Object',
    require: false,
  },
});

export default mongoose.model<ICourseCategory>(
  'CourseCategory',
  CourseCategorySchema
);
