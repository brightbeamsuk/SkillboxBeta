import { CreateQuery } from 'mongoose';
import CourseCategory, { ICourseCategory } from './model';
import L from '../../../common/logger';
import { DocDB } from 'aws-sdk';
export class CourseCategoryService {
  async findAll(): Promise<ICourseCategory[]> {
    try {
      return await CourseCategory.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICourseCategory> {
    try {
      return await CourseCategory.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICourseCategory>): Promise<ICourseCategory> {
    try {
      const categoryCount = await CourseCategory.countDocuments({
        title: RegExp('^' + body.title + '$', 'i'),
        parent_id: body.parent_id,
      });
      if (categoryCount > 0) throw new Error('Title already exist');
      return await CourseCategory.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<ICourseCategory>,
    id: string
  ): Promise<ICourseCategory> {
    try {
      const categoryCount = await CourseCategory.countDocuments({
        _id: { $ne: id },
        title: RegExp('^' + body.title + '$', 'i'),
        parent_id: body.parent_id,
      });
      if (categoryCount > 0) throw new Error('Title already exist');
      return await CourseCategory.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICourseCategory> {
    try {
      return await CourseCategory.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await CourseCategory.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await CourseCategory.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getParent(): Promise<ICourseCategory[]> {
    try {
      const categories = await CourseCategory.find({ parent_id: '0' });
      for (const category of categories) {
        const child = await CourseCategory.find({ parent_id: category._id });
        category.child = child;
      }
      console.log(categories);
      return categories;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CourseCategoryService();
