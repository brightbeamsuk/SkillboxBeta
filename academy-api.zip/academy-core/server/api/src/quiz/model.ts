import mongoose, { Schema, Document } from 'mongoose';
import { IQuestion } from './../question/model';
export interface IQuiz extends Document {
  name: 'string';
  description: 'string';
  is_published: boolean;
  start_time: 'string';
  end_time: 'string';
  no_of_attempt: 'number';
  review: 'boolean';
  shuffle: 'boolean';
  no_of_questions: 'number';
  time_limit: 'number';
  questions?: IQuestion[];
  course?: any;
  chapter?: any;
}

const QuizSchema: Schema = new Schema({
  name: {
    type: 'String',
    require: true,
  },
  description: {
    type: 'String',
    require: true,
  },
  is_published: {
    type: 'Boolean',
    require: true,
  },
  start_time: {
    type: 'String',
    require: true,
  },
  end_time: {
    type: 'String',
    require: true,
  },
  no_of_attempt: {
    type: 'Number',
    require: true,
  },
  review: {
    type: 'Boolean',
    require: true,
  },
  shuffle: {
    type: 'Boolean',
    require: true,
  },
  no_of_questions: {
    type: 'Number',
    require: true,
  },
  time_limit: {
    type: 'Number',
    require: true,
  },
  questions: {
    type: 'Object',
    require: false,
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
  chapter: {
    ref: 'Chapters',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuiz>('Quiz', QuizSchema);
