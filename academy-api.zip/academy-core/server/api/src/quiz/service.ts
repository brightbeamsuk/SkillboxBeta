import { CreateQuery } from 'mongoose';
import Quiz, { IQuiz } from './model';
import L from '../../../common/logger';
export class QuizService {
  async findAll(): Promise<IQuiz[]> {
    try {
      return await Quiz.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IQuiz> {
    try {
      return await Quiz.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async showChapterQuiz(course: string, chapter: string): Promise<IQuiz[]> {
    try {
      return await Quiz.find({ course, chapter });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IQuiz>): Promise<IQuiz> {
    try {
      const quizCount = await Quiz.countDocuments({
        name: RegExp('^' + body.name + '$', 'i'),
        course: body.course,
        chapter: body.chapter,
      });
      if (quizCount > 0) throw new Error('Title already exist');
      return await Quiz.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IQuiz> {
    try {
      const quizCount = await Quiz.countDocuments({
        _id: { $ne: id },
        name: RegExp('^' + body.name + '$', 'i'),
        course: body.course,
        chapter: body.chapter,
      });
      if (quizCount > 0) throw new Error('Title already exist');
      return await Quiz.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IQuiz> {
    try {
      return await Quiz.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Quiz.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Quiz.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new QuizService();
