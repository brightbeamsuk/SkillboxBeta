import mongoose, { Schema, Document } from 'mongoose';

export interface IAddress extends Document {
  address1: 'string';
  address2: 'string';
  city: 'string';
  postal_code: 'string';
  location: any;
  country: 'string';
}

const AddressSchema: Schema = new Schema({
  address1: {
    type: 'String',
    require: true,
  },
  address2: {
    type: 'String',
    require: false,
  },
  city: {
    type: 'String',
    require: true,
  },
  postal_code: {
    type: 'String',
    require: false,
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      required: true,
    },
    coordinates: {
      type: [Number],
      required: true,
    },
  },
  country: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IAddress>('Address', AddressSchema);
