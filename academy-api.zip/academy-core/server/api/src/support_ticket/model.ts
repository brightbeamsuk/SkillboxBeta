import mongoose, { Schema, Document } from 'mongoose';

export interface ISupportTicket extends Document {
  email: 'string';
  message: 'string';
  title: 'string';
}

const SupportTicketSchema: Schema = new Schema({
  email: {
    type: 'String',
    require: true,
  },
  title: {
    type: 'String',
    require: true,
  },
  message: {
    type: 'String',
    require: true,
  },
  status: {
    type: 'String',
    require: true,
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<ISupportTicket>(
  'SupportTicket',
  SupportTicketSchema
);
