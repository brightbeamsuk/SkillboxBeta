import mongoose, { Schema, Document } from 'mongoose';

export type IProfilePermissions = Document;

const ProfilePermissionsSchema: Schema = new Schema({
  profile_type: {
    ref: 'ProfileType',
    type: 'ObjectId',
  },
  permission: {
    ref: 'Permissions',
    type: 'ObjectId',
  },
});

export default mongoose.model<IProfilePermissions>(
  'ProfilePermissions',
  ProfilePermissionsSchema
);
