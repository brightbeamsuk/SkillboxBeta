import { CreateQuery } from 'mongoose';
import ProfilePermissions, { IProfilePermissions } from './model';
import L from '../../../common/logger';
export class ProfilePermissionsService {
  async findAll(): Promise<IProfilePermissions[]> {
    try {
      return await ProfilePermissions.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IProfilePermissions> {
    try {
      return await ProfilePermissions.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(
    body: CreateQuery<IProfilePermissions>
  ): Promise<IProfilePermissions> {
    try {
      return await ProfilePermissions.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IProfilePermissions>,
    id: string
  ): Promise<IProfilePermissions> {
    try {
      return await ProfilePermissions.findByIdAndUpdate(id, body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IProfilePermissions> {
    try {
      return await ProfilePermissions.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ProfilePermissions.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ProfilePermissions.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ProfilePermissionsService();
