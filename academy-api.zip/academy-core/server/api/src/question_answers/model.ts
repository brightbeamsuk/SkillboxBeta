import mongoose, { Schema, Document } from 'mongoose';

export interface IQuestionAnswers extends Document {
  option: string;
  question: string;
}

const QuestionAnswersSchema: Schema = new Schema({
  question: {
    ref: 'Question',
    type: 'ObjectId',
  },
  option: {
    ref: 'Options',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuestionAnswers>(
  'QuestionAnswers',
  QuestionAnswersSchema
);
