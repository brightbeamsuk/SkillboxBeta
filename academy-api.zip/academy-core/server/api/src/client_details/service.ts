import { CreateQuery } from 'mongoose';
import ClientDetails, { IClientDetails } from './model';
import L from '../../../common/logger';
export class ClientDetailsService {
  async findAll(): Promise<IClientDetails[]> {
    try {
      return await ClientDetails.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IClientDetails> {
    try {
      return await ClientDetails.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IClientDetails>): Promise<IClientDetails> {
    try {
      return await ClientDetails.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IClientDetails>,
    id: string
  ): Promise<IClientDetails> {
    try {
      return await ClientDetails.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IClientDetails> {
    try {
      return await ClientDetails.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ClientDetails.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ClientDetails.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ClientDetailsService();
