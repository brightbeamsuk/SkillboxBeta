import mongoose, { Schema, Document } from 'mongoose';

export type IClientDetails = Document;

const ClientDetailsSchema: Schema = new Schema({
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  plan_details: {
    ref: 'PlanDetails',
    type: 'ObjectId',
  },
});

export default mongoose.model<IClientDetails>(
  'ClientDetails',
  ClientDetailsSchema
);
