import mongoose, { Schema, Document } from 'mongoose';

export interface IAppSettings extends Document {
  value: string;
  slug: string;
}

const AppSettingsSchema: Schema = new Schema({
  value: {
    type: 'String',
    require: true,
  },
  slug: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IAppSettings>('AppSettings', AppSettingsSchema);
