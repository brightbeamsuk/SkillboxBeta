import { CreateQuery } from 'mongoose';
import AppSettings, { IAppSettings } from './model';
import L from '../../../common/logger';
export class AppSettingsService {
  async findAll(): Promise<IAppSettings[]> {
    try {
      return await AppSettings.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IAppSettings> {
    try {
      return await AppSettings.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findBySlug(slug: string): Promise<IAppSettings> {
    try {
      return await AppSettings.findOne({ slug });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IAppSettings>): Promise<IAppSettings> {
    try {
      return await AppSettings.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async addOrUpdate(body: CreateQuery<IAppSettings>): Promise<IAppSettings> {
    try {
      if (body.slug) {
        const appSettings = await AppSettings.findOne({ slug: body.slug });
        if (appSettings) {
          appSettings.value = body.value;
          return await AppSettings.findByIdAndUpdate(appSettings._id, body, {
            new: true,
          });
        } else {
          return await AppSettings.create(body);
        }
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IAppSettings>,
    id: string
  ): Promise<IAppSettings> {
    try {
      return await AppSettings.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IAppSettings> {
    try {
      return await AppSettings.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await AppSettings.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await AppSettings.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new AppSettingsService();
