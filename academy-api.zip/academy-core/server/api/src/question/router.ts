import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/quiz/:id', tokenVerify, controller.quizQuestions)
  .post('/', tokenVerify, controller.store)
  .post('/add', tokenVerify, controller.addQuestion)
  .put('/:id', tokenVerify, controller.update)
  .put('/update/:id', tokenVerify, controller.updateQuestion)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/delete/:id', tokenVerify, controller.deleteQuestion)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
