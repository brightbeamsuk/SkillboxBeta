import mongoose, { Schema, Document } from 'mongoose';
import { IOptions } from './../options/model';
import { IQuestionAnswers } from './../question_answers/model';
import { IQuizAttemptOptions } from './../quiz_attempt_options/model';
export interface IQuestion extends Document {
  name: 'string';
  type: string;
  code: 'string';
  options: IOptions[];
  answers: IQuestionAnswers[];
  attemptOption?: IQuizAttemptOptions[];
}

const QuestionSchema: Schema = new Schema({
  name: {
    type: 'String',
    require: true,
  },
  type: {
    type: 'String',
    require: true,
  },
  code: {
    type: 'String',
    require: true,
  },
  options: {
    type: 'Object',
    require: false,
  },
  answers: {
    type: 'Object',
    require: false,
  },
  attemptOption: {
    type: 'Object',
    require: false,
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuestion>('Question', QuestionSchema);
