import { CreateQuery } from 'mongoose';
import Question, { IQuestion } from './model';
import QuizQuestions from './../quiz_questions/model';
import QuestionAnswers from '../question_answers/model';
import Options from '../options/model';
import L from '../../../common/logger';
export class QuestionService {
  async findAll(): Promise<IQuestion[]> {
    try {
      return await Question.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IQuestion> {
    try {
      return await Question.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async quizQuestions(id: any): Promise<IQuestion[]> {
    try {
      const questionIds = [];
      const quizQuestions = await QuizQuestions.find(
        { quiz: id },
        { question: 1, _id: 0 }
      );
      for (const q of quizQuestions) {
        questionIds.push(q.question);
      }
      const questions = await Question.find({ _id: { $in: questionIds } });
      for (const question of questions) {
        const options = await Options.find({ question: question._id });
        question.options = options;

        const answer = await QuestionAnswers.find({ question: question._id });
        question.answers = answer;
      }
      return questions;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IQuestion>): Promise<IQuestion> {
    try {
      return await Question.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async addQuestion(body: any): Promise<IQuestion> {
    try {
      // 1. create question
      // 2. map with quiz question
      // 3. add quiz options
      // 4. add add correct answer
      const answers = body.answers;
      delete body.answers;
      const question = await Question.create(body);
      await QuizQuestions.create({
        quiz: body.quiz,
        question: question._id,
      });
      for (const answer of answers) {
        const option = await Options.create({
          name: answer.option,
          question: question._id,
        });
        if (answer.correct) {
          await QuestionAnswers.create({
            question: question._id,
            option: option._id,
          });
        }
      }
      const options = await Options.find({ question: question._id });
      question.options = options;

      const answer = await QuestionAnswers.find({ question: question._id });
      question.answers = answer;
      return question;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IQuestion> {
    try {
      return await Question.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async updateQuestion(body: any, id: any): Promise<IQuestion> {
    try {
      const answers = body.answers;
      delete body.answers;
      const question = await Question.findByIdAndUpdate(id, body, {
        new: true,
      });
      await QuestionAnswers.deleteMany({ question: id });
      for (const answer of answers) {
        const option = await Options.findByIdAndUpdate(answer._id, {
          name: answer.option,
        });
        if (answer.correct) {
          await QuestionAnswers.create({
            question: id,
            option: option._id,
          });
        }
      }
      const options = await Options.find({ question: id });
      question.options = options;

      const answer = await QuestionAnswers.find({ question: id });
      question.answers = answer;
      return await question;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IQuestion> {
    try {
      return await Question.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteQuestion(id: any): Promise<IQuestion> {
    try {
      const question = Question.findByIdAndDelete(id);
      await Options.deleteMany({ question: id });
      await QuestionAnswers.deleteMany({ question: id });
      await QuizQuestions.deleteMany({ question: id });
      return question;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Question.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Question.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new QuestionService();
