import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/candidate/:profile', tokenVerify, controller.getCandidateCertficates)
  .get(
    '/generate-missing-certificate/:profile',
    tokenVerify,
    controller.generateMissingCertificate
  )
  .post('/', tokenVerify, controller.store)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
