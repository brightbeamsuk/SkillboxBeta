import { CreateQuery } from 'mongoose';
import Certificate, { ICertificate } from './model';
import Course, { ICourse } from './../course/model';
import CourseEnroll from './../course_enroll/model';
import Profile, { IProfile } from './../profile/model';
import EmailTemplates from './../emailtemplates/model';
import ClientUser from '../client_users/model';
import Quiz from './../quiz/model';
import QuizAttempt from './../quiz_attempt/model';

import L from '../../../common/logger';
import MailGun from '../../../common/email/mail.gun';

import pdfMake from 'pdfmake/build/pdfmake.js';
import pdfFonts from 'pdfmake/build/vfs_fonts.js';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import * as fs from 'fs';
import moment from 'moment';
import path from 'path';
import AWS from 'aws-sdk';
export class CertificateService {
  async findAll(): Promise<ICertificate[]> {
    try {
      return await Certificate.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICertificate> {
    try {
      return await Certificate.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getCandidateCertficates(profile: string): Promise<ICertificate[]> {
    try {
      const responce = [];
      const certificates = await Certificate.find({
        profile: profile,
      })
        .populate('course')
        .populate('profile');
      for (const certificate of certificates) {
        if (certificate.course.parent_id == '') {
          responce.push(certificate);
        }
      }
      return responce;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICertificate>): Promise<ICertificate> {
    try {
      const course = await Course.findById(body.course);
      const profile = await Profile.findById(body.profile);
      await this.generateCertificate(course, profile, body);
      await this.sendCourseCompleteEmail(course, profile, body);
      await setTimeout(async () => {
        return await this.generateCertificateForGroupCourse(profile, body);
      }, 5000);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<ICertificate> {
    try {
      return await Certificate.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICertificate> {
    try {
      return await Certificate.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Certificate.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Certificate.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async base64_encode(file: string): Promise<string> {
    const bitmap = fs.readFileSync(file);
    return 'data:image/png;base64,' + Buffer.from(bitmap).toString('base64');
  }

  async generateCertificate(
    course: ICourse,
    profile: IProfile,
    certficate: any
  ): Promise<any> {
    try {
      const certificateAsset = process.env.CERTIFICATE_LOGO_DIR;
      const imagePath = path.join(
        __dirname,
        `../../../../public/assets/images/${certificateAsset}`
      );
      const certficateLogo = await this.base64_encode(
        imagePath + '/certificate-logo.png'
      );
      const cpdLogo = await this.base64_encode(imagePath + '/cpd_logo.png');
      const trainerSign = await this.base64_encode(
        imagePath + '/trainer_sign.png'
      );
      const directorSign = await this.base64_encode(
        imagePath + '/ceo_sign.png'
      );
      const backpdf = await this.base64_encode(imagePath + '/backpdf.png');

      const docDefinition = {
        pageSize: 'A4',
        background: [
          {
            image: backpdf,
            width: 600,
            absolutePosition: { x: 0, y: 0 },
          },
        ],
        content: [
          {
            image: certficateLogo,
            width: 275,
            style: 'logo',
            margin: [0, 60, 0, 0],
          },
          {
            text: 'This certificate has been awarded to',
            style: 'content',
            margin: [0, 30, 0, 0],
          },
          {
            text: `${profile.first_name} ${profile.last_name}`,
            color: '#0e3c63',
            fontSize: 30,
            style: 'header',
            margin: [0, 30],
          },
          {
            text: 'who successfully completed the CPD accredited',
            style: 'content',
          },
          {
            text: course.title,
            style: 'header',
            margin: [0, 20, 0, 0],
          },
          {
            text: 'online training on the',
            style: 'content',
            margin: [0, 20, 0, 0],
          },
          {
            text: moment().format('DD/MM/YYYY'),
            style: 'header',
            margin: [0, 20, 0, 0],
          },
          {
            style: 'tableExample',
            table: {
              widths: ['*', '*'],
              body: [
                [
                  {
                    image: trainerSign,
                    width: 150,
                    style: 'logo',
                    margin: [0, 0, 0, 0],
                  },
                  {
                    image: directorSign,
                    width: 150,
                    style: 'logo',
                    margin: [0, 0, 0, 0],
                  },
                ],
                [
                  {
                    text: process.env.CERTIFICATE_TRAINER_NAME,
                    style: 'signatureContent',
                    alignment: 'center',
                  },
                  {
                    text: process.env.CERTIFICATE_CEO_NAME,
                    style: 'signatureContent',
                    alignment: 'center',
                  },
                ],
                [
                  {
                    text: 'Training Director',
                    style: 'signatureContent',
                    alignment: 'center',
                  },
                  {
                    text: 'Managing Director',
                    style: 'signatureContent',
                    alignment: 'center',
                  },
                ],
              ],
            },
            layout: 'noBorders',
          },
          {
            image: cpdLogo,
            width: 200,
            style: 'logo',
            margin: [0, 20, 0, 0],
          },
        ],
        footer: {
          text: 'Certificate requires update 1 year from date of issue.',
          style: 'signatureContent',
          color: '#ffffff',
        },
        styles: {
          header: {
            fontSize: 18,
            bold: true,
            alignment: 'center',
          },
          content: {
            fontSize: 15,
            alignment: 'center',
          },
          signatureContent: {
            fontSize: 13,
            alignment: 'center',
          },
          logo: {
            alignment: 'center',
          },
          tableExample: {
            margin: [0, 25, 0, 15],
          },
        },
      };
      pdfMake.createPdf(docDefinition).getBase64(async (buffer) => {
        const BUCKET = process.env.AWS_S3_BUCKET;
        const REGION = process.env.AWS_REGION;
        const ACCESS_KEY = process.env.AWS_ACCESS_KEY_ID;
        const SECRET_KEY = process.env.AWS_SECRET_ACCESS_KEY;
        const FILE_NAME = course.title.replace(/ /g, '_');
        AWS.config.update({
          accessKeyId: ACCESS_KEY,
          secretAccessKey: SECRET_KEY,
          region: REGION,
        });
        const s3 = new AWS.S3();
        const pars = {
          Bucket: BUCKET,
          Body: Buffer.from(
            buffer.replace(/^data:image\/\w+;base64,/, ''),
            'base64'
          ),
          Key:
            Math.random().toString(36).substring(7) +
            '_' +
            FILE_NAME.toLowerCase(),
          ContentType: 'application/pdf',
          ACL: 'public-read',
        };
        const s3Res = await s3.upload(pars).promise();
        certficate.certificate_url = s3Res.Location;
        await Certificate.create(certficate);
        await CourseEnroll.findOneAndUpdate(
          { course: certficate.course, profile: certficate.profile },
          { completed: true }
        );
      });
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async generateCertificateForGroupCourse(
    profile: IProfile,
    _certficate: any
  ): Promise<any> {
    try {
      const enrolls = await CourseEnroll.find({
        profile: profile,
      }).populate('course');
      for (const enroll of enrolls) {
        if (enroll.course.type === 'Group') {
          // Check cerfificate exist for grouo course, if not create one from sub course
          const certificate = await Certificate.findOne({
            profile: profile._id,
            course: enroll.course._id,
          });
          if (!certificate) {
            // Check all sub courses completed and score 80 and above
            const params = {
              parent_id: enroll.course._id,
              published: true,
            };
            const subCourses = await Course.find(params);
            const totalSubCourse = subCourses.length;
            let completedCourse = 0; // Score 80 and above
            let subCourseScore = 0;
            for (const sCourse of subCourses) {
              const sCourseCertificate = await Certificate.findOne({
                profile: profile._id,
                course: sCourse._id,
              });
              if (sCourseCertificate && sCourseCertificate.grade >= 80) {
                completedCourse++;
                subCourseScore = subCourseScore + sCourseCertificate.grade;
              }
            }
            const score = subCourseScore / totalSubCourse;
            if (totalSubCourse === completedCourse) {
              // Generate Group course certificate
              _certficate.course = enroll.course._id;
              _certficate.grade = score;
              await this.generateCertificate(
                enroll.course,
                profile,
                _certficate
              );
            }
          }
        }
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async generateMissingCertificate(profileId: string): Promise<any> {
    try {
      const candidateAssignedCourses = await CourseEnroll.find({
        profile: profileId,
      });
      for (const assigned of candidateAssignedCourses) {
        const quizes = await Quiz.find({ course: assigned.course });
        for (const quiz of quizes) {
          const attempt = await QuizAttempt.findOne({
            quiz: quiz._id,
            profile: profileId,
          }).sort({ _id: -1 });
          if (attempt) {
            const profile = await Profile.findById(profileId);
            const course = await Course.findById(assigned.course);
            const certficate = await Certificate.findOne({
              course: assigned.course,
              profile: profileId,
            });
            if (!certficate && attempt.mark >= 80) {
              const certificate = {
                course: assigned.course,
                profile: profileId,
                date: moment.utc().format(),
                exp_date: moment.utc().add(1, 'year'),
                grade: attempt.mark,
              };
              await this.generateCertificate(course, profile, certificate);
            }
          }
        }
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async sendCourseCompleteEmail(
    course: ICourse,
    profile: IProfile,
    certficate: any
  ): Promise<any> {
    try {
      const clientProfile = await ClientUser.findOne({
        profile: profile._id,
      });
      const dynamicContent = {
        '[candidate_name]': `${profile.first_name} ${profile.last_name}`,
        '[course_name]': course.title,
        '[grade]': certficate.grade,
      };
      const mailTemplate = await EmailTemplates.findOne({
        slug: 'course-complete',
        client: clientProfile.client_profile,
      });
      let content = mailTemplate.body;
      for (const key in dynamicContent) {
        if (Object.prototype.hasOwnProperty.call(dynamicContent, key)) {
          content = content.replace(key, dynamicContent[key]);
        }
      }
      const subject = mailTemplate.subject;
      const receipients = mailTemplate.receipients.split(',');
      for (const receipient of receipients) {
        MailGun.send(profile.email, receipient, subject, 'course-completed', {
          body: content,
        });
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CertificateService();
