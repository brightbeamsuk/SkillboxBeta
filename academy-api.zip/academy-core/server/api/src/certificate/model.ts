import mongoose, { Schema, Document } from 'mongoose';

export interface ICertificate extends Document {
  date: 'date';
  exp_date: 'date';
  grade: number;
  remaining_days?: number;
  certificate_url?: string;
  course?: any;
  profile?: string;
}

const CertificateSchema: Schema = new Schema({
  date: {
    type: 'Date',
    require: true,
  },
  exp_date: {
    type: 'Date',
    require: false,
  },
  grade: {
    type: 'Number',
    require: false,
  },
  remaining_days: {
    type: 'Number',
    require: false,
  },
  certificate_url: {
    type: 'String',
    require: false,
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICertificate>('Certificate', CertificateSchema);
