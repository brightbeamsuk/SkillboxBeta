import mongoose, { Schema, Document } from 'mongoose';

export interface IPlanDetails extends Document {
  limit_from: 'number';
  limit_to: 'number';
  price: 'number';
  profile?: 'string';
  plan?: 'string';
}

const PlanDetailsSchema: Schema = new Schema({
  limit_from: {
    type: 'Number',
    require: true,
  },
  limit_to: {
    type: 'Number',
    require: true,
  },
  price: {
    type: 'Number',
    require: true,
  },
  plan: {
    ref: 'Plans',
    type: 'ObjectId',
  },
});

export default mongoose.model<IPlanDetails>('PlanDetails', PlanDetailsSchema);
