import { CreateQuery } from 'mongoose';
import ClientUsers, { IClientUsers } from './model';
import CourseEnroll from './../course_enroll/model';
import ProfileType from './../profile_type/model';
import L from '../../../common/logger';
export class ClientUsersService {
  async findAll(): Promise<IClientUsers[]> {
    try {
      return await ClientUsers.find()
        .populate('client_profile')
        .populate('profile');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IClientUsers> {
    try {
      return await ClientUsers.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getCandidates(clientId: string): Promise<IClientUsers[]> {
    try {
      const responce = [];
      const candidates = await ClientUsers.find({
        client_profile: clientId,
      }).populate('profile');
      const profileType = await ProfileType.findOne({ slug: 'candidate' });
      for (const candidate of candidates) {
        console.log(candidate.profile.profile_type, profileType._id);
        if (
          candidate.profile &&
          candidate.profile.profile_type.equals(profileType._id)
        ) {
          const enroll = await CourseEnroll.countDocuments({
            profile: candidate.profile._id,
          });
          candidate.profile.total_course = enroll;
          candidate.profile.profile_type = profileType;
          responce.push(candidate.profile);
        }
      }
      return responce;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getUsers(clientId: string): Promise<IClientUsers[]> {
    try {
      const responce = [];
      const users = await ClientUsers.find({
        client_profile: clientId,
      }).populate('profile');
      const profileType = await ProfileType.findOne({ slug: 'system_users' });
      for (const user of users) {
        if (user.profile) {
          if (user.profile.profile_type.equals(profileType._id)) {
            user.profile.profile_type = profileType;
            responce.push(user.profile);
          }
        }
      }
      return responce;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getCourseCompletedCandidates(
    clientId: string
  ): Promise<IClientUsers[]> {
    try {
      const responce = [];
      const candidates = await ClientUsers.find({
        client_profile: clientId,
      });
      const candidateIds = [];
      for (const candidate of candidates) {
        candidateIds.push(candidate.profile);
      }
      const enrolls = await CourseEnroll.find({
        profile: { $in: candidateIds },
        completed: true,
      }).populate('profile');
      for (const enroll of enrolls) {
        responce.push(enroll.profile);
      }
      return responce.filter(
        (v, i, a) => a.findIndex((t) => t._id === v._id) === i
      );
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getClient(profileId: string): Promise<IClientUsers> {
    try {
      const client = await ClientUsers.findOne({
        profile: profileId,
      }).populate('client_profile');
      return client;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IClientUsers>): Promise<IClientUsers> {
    try {
      return await ClientUsers.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IClientUsers>,
    id: string
  ): Promise<IClientUsers> {
    try {
      return await ClientUsers.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IClientUsers> {
    try {
      return await ClientUsers.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ClientUsers.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ClientUsers.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ClientUsersService();
