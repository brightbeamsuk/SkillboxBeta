import mongoose, { Schema, Document } from 'mongoose';
export interface IClientUsers extends Document {
  profile?: any;
  client_profile?: any;
}

const ClientUsersSchema: Schema = new Schema({
  client_profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<IClientUsers>('ClientUsers', ClientUsersSchema);
