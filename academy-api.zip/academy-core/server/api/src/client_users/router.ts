import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/get_candidates/:client_id', tokenVerify, controller.getCandidates)
  .get('/client/get_users/:client_id', tokenVerify, controller.getUsers)
  .get(
    '/get_course_completed_candidates/:client_id',
    tokenVerify,
    controller.getCourseCompletedCandidates
  )
  .get('/get_client/:profile_id', tokenVerify, controller.getClient)
  .post('/', tokenVerify, controller.store)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
