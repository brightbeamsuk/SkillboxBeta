import mongoose, { Schema, Document } from 'mongoose';

export interface IEmailSettings extends Document {
  driver: 'string';
  host: 'string';
  port: 'string';
  username: 'string';
  password: 'string';
  encryption: 'string';
  from_address: 'string';
  from_name: 'string';
}

const EmailSettingsSchema: Schema = new Schema({
  driver: {
    type: 'String',
    require: true,
  },
  host: {
    type: 'String',
    require: true,
  },
  port: {
    type: 'String',
    require: true,
  },
  username: {
    type: 'String',
    require: true,
  },
  password: {
    type: 'String',
    require: true,
  },
  encryption: {
    type: 'String',
    require: true,
  },
  from_address: {
    type: 'String',
    require: true,
  },
  from_name: {
    type: 'String',
    require: true,
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<IEmailSettings>(
  'EmailSettings',
  EmailSettingsSchema
);
