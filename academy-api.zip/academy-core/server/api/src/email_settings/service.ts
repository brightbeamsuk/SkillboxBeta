import { CreateQuery } from 'mongoose';
import EmailSettings, { IEmailSettings } from './model';
import L from '../../../common/logger';
export class EmailSettingsService {
  async findAll(): Promise<IEmailSettings[]> {
    try {
      return await EmailSettings.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IEmailSettings> {
    try {
      return await EmailSettings.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IEmailSettings>): Promise<IEmailSettings> {
    try {
      return await EmailSettings.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IEmailSettings>,
    id: string
  ): Promise<IEmailSettings> {
    try {
      return await EmailSettings.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IEmailSettings> {
    try {
      return await EmailSettings.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await EmailSettings.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await EmailSettings.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new EmailSettingsService();
