import mongoose, { Schema, Document } from 'mongoose';

export interface ICourseOutcome extends Document {
  title: 'string';
}

const CourseOutcomeSchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICourseOutcome>(
  'CourseOutcome',
  CourseOutcomeSchema
);
