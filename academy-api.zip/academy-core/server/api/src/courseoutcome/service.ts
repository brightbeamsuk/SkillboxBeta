import { CreateQuery } from 'mongoose';
import CourseOutcome, { ICourseOutcome } from './model';
import L from '../../../common/logger';
export class CourseOutcomeService {
  async findAll(): Promise<ICourseOutcome[]> {
    try {
      return await CourseOutcome.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICourseOutcome> {
    try {
      return await CourseOutcome.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async courseOutcome(id: string): Promise<ICourseOutcome[]> {
    try {
      return await CourseOutcome.find({ course: id });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICourseOutcome>): Promise<ICourseOutcome> {
    try {
      return await CourseOutcome.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<ICourseOutcome>,
    id: string
  ): Promise<ICourseOutcome> {
    try {
      return await CourseOutcome.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICourseOutcome> {
    try {
      return await CourseOutcome.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await CourseOutcome.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await CourseOutcome.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CourseOutcomeService();
