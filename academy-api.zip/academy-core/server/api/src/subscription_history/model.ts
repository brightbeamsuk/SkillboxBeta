import mongoose, { Schema, Document } from 'mongoose';

  export interface ISubscriptionHistory extends Document {
    "amount": "number",
    "date": "string",
    "type": "string",
    "quantity": "number"
}

  const SubscriptionHistorySchema: Schema = new Schema(
    {
    "amount": {
        "type": "Number",
        "require": true
    },
    "date": {
        "type": "String",
        "require": true
    },
    "type": {
        "type": "String",
        "require": true
    },
    "quantity": {
        "type": "Number",
        "require": true
    },
    "subscription": {
        "ref": "Subscription",
        "type": "ObjectId"
    }
}
  );
  
  export default mongoose.model<ISubscriptionHistory>('SubscriptionHistory', SubscriptionHistorySchema);