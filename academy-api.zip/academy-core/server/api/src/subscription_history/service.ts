import { CreateQuery } from 'mongoose';
import SubscriptionHistory, { ISubscriptionHistory } from './model';
import L from '../../../common/logger';
export class SubscriptionHistoryService {
  async findAll(): Promise<ISubscriptionHistory[]> {
    try {
      return await SubscriptionHistory.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ISubscriptionHistory> {
    try {
      return await SubscriptionHistory.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ISubscriptionHistory>): Promise<ISubscriptionHistory> {
    try {
      return await SubscriptionHistory.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: CreateQuery<ISubscriptionHistory>, id: string): Promise<ISubscriptionHistory> {
    try {
      return await SubscriptionHistory.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ISubscriptionHistory> {
    try {
      return await SubscriptionHistory.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await SubscriptionHistory.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await SubscriptionHistory.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new SubscriptionHistoryService();
