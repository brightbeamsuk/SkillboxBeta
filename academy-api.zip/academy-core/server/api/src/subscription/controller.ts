import SubscriptionService from './service';
import { Request, Response } from 'express';
export class Controller {
  /**
   * List all records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  index(req: Request, res: Response): void {
    SubscriptionService.findAll().then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  show(req: Request, res: Response): void {
    const id = req.params['id'];
    SubscriptionService.findById(id).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  store(req: Request, res: Response): void {
    const body = req.body;
    SubscriptionService.create(body).then((r) => res.json(r));
  }

  createProduct(req: Request, res: Response): void {
    const body = req.body;
    SubscriptionService.createProduct(body).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  createCheckoutSession(req: Request, res: Response): void {
    const body = req.body;
    SubscriptionService.createCheckoutSession(body).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  stripeWebhookEvent(req: Request, res: Response): void {
    const body = req.body;
    const signature = req.headers['stripe-signature'];
    const rawBody = req['rawBody'];
    SubscriptionService.stripeWebHook(body, signature, rawBody).then((r) =>
      res.json(r)
    );
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  activateClient(req: Request, res: Response): void {
    const body = req.body;
    SubscriptionService.activateClient(body).then((r) => res.json(r));
  }

  /**
   * Create new subscription
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  addSubscription(req: Request, res: Response): void {
    const body = req.body;
    SubscriptionService.addSubscription(body).then((r) => res.json(r));
  }

  /**
   * Get subscribed course
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  getSubscribedCourse(req: Request, res: Response): void {
    const id = req.params['id'];
    SubscriptionService.getSubscribedCourse(id).then((r) => res.json(r));
  }
  /**
   * Update record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  update(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['id'];
    SubscriptionService.update(body, id).then((r) => res.json(r));
  }

  /**
   * Delete record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  delete(req: Request, res: Response): void {
    const id = req.params['id'];
    SubscriptionService.deleteById(id).then((r) => res.json(r));
  }

  /**
   * Delete all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  deleteAll(req: Request, res: Response): void {
    SubscriptionService.deleteAll().then((r) => res.json(r));
  }

  /**
   * Count all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  count(req: Request, res: Response): void {
    SubscriptionService.count().then((r) => res.json(r));
  }
}

export default new Controller();
