import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .post('/', tokenVerify, controller.store)
  .post('/create-product', tokenVerify, controller.createProduct)
  .post(
    '/create-checkout-session',
    tokenVerify,
    controller.createCheckoutSession
  )
  .post('/stripe-web-hook', controller.stripeWebhookEvent)
  .post('/activate-client', controller.activateClient)
  .post('/add-offline-subscription', controller.addSubscription)
  .get('/subscribed-course/:id', tokenVerify, controller.getSubscribedCourse)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
