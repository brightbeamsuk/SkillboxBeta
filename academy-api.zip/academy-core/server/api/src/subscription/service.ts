import { CreateQuery } from 'mongoose';
import Subscription, { ISubscription } from './model';
import SubscriptionHistory, {
  ISubscriptionHistory,
} from './../subscription_history/model';
import Profile from './../profile/model';
import CourseEnroll from './../course_enroll/model';
import Stripe from 'stripe';

import L from '../../../common/logger';
export class SubscriptionService {
  async findAll(): Promise<ISubscription[]> {
    try {
      return await Subscription.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ISubscription> {
    try {
      return await Subscription.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ISubscription>): Promise<ISubscription> {
    try {
      return await Subscription.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createProduct(body: any): Promise<any> {
    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2020-08-27',
      });
      const product = await stripe.products.create({
        name: body.subscription_name,
      });
      const price = await stripe.prices.create({
        unit_amount: body.amount,
        currency: 'gbp',
        recurring: { interval: body.type },
        product: product.id,
      });
      return { product, price };
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createCheckoutSession(body: any): Promise<any> {
    const { priceId } = body;
    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2020-08-27',
      });
      const session = await stripe.checkout.sessions.create({
        mode: 'subscription',
        payment_method_types: ['card'],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        success_url: process.env.STRIPE_SUBSCRIPTION_SUCCESS_URL,
        cancel_url: process.env.STRIPE_SUBSCRIPTION_FAILED_URL,
      });
      return session;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async stripeWebHook(body: any, signature: any, rawBody: any): Promise<any> {
    try {
      let data;
      let eventType;
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2020-08-27',
      });
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      let event;
      if (webhookSecret) {
        try {
          event = stripe.webhooks.constructEvent(
            rawBody,
            signature,
            webhookSecret
          );
        } catch (err) {
          console.log(`⚠️ Webhook signature verification failed.`);
          throw new Error('Webhook signature verification failed');
        }
        // Extract the object from the event.
        data = event.data;
        eventType = event.type;
      } else {
        data = body.data;
        eventType = body.type;
      }
      switch (event.type) {
        case 'checkout.session.completed':
          console.log('Subscribed successfully');
          const bdata = {
            subscription_id: data.object.id,
            subscription_name: '',
            type: 'Subscription',
            customer_id: data.object.customer,
            profile: '',
            amount: data.object.total,
            available_credit: 0,
            total_credit: 0,
            quantity: 0,
          };
          await Subscription.create(bdata);
          break;
        case 'invoice.paid':
          console.log('invoice paid');
          // maintain transaction logs
          break;
        case 'invoice.payment_failed':
          console.log('invoice failed');
          break;
        default:
          console.log('something went wrong');
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async activateClient(body: any): Promise<any> {
    try {
      const oldSubscription = await Subscription.find({
        profile: body.profile_id,
      })
        .sort({ _id: -1 })
        .limit(1);
      if (oldSubscription.length > 0) {
        const newSub = await Subscription.findByIdAndUpdate(
          oldSubscription[0]._id,
          {
            type: body.type,
            subscription_id: body.id,
            profile: body.profile_id,
            available_credit:
              oldSubscription[0].available_credit + +body.available_credit,
            total_credit: oldSubscription[0].total_credit + body.total_credit,
            quantity: oldSubscription[0].quantity + +body.quantity,
            amount: +body.amount,
          },
          { new: true }
        );
        await SubscriptionHistory.create({
          amount: body.amount,
          date: body.date,
          type: body.type,
          quantity: body.quantity,
          subscription: newSub._id,
        });
        const prf = await Profile.findByIdAndUpdate(
          body.profile_id,
          { status: 'paid' },
          { new: true }
        )
          .populate('profile_type')
          .populate('address');
        return { profile: prf, subscription: newSub };
      } else {
        console.log('no subscription found');
        return true;
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async addSubscription(body: any): Promise<ISubscriptionHistory> {
    try {
      const oldSubscription = await Subscription.find({
        profile: body.profile_id,
      })
        .sort({ _id: -1 })
        .limit(1);
      let subscription: ISubscription;
      if (oldSubscription.length > 0) {
        subscription = await Subscription.findByIdAndUpdate(
          oldSubscription[0]._id,
          {
            type: body.type,
            profile: body.profile_id,
            available_credit:
              oldSubscription[0].available_credit + +body.quantity,
            total_credit: oldSubscription[0].total_credit + body.quantity,
            quantity: oldSubscription[0].quantity + +body.quantity,
            amount: +body.amount,
          },
          { new: true }
        );
      } else {
        subscription = await Subscription.create({
          type: body.type,
          subscription_id: body.subscription_id,
          profile: body.profile_id,
          available_credit: body.quantity,
          total_credit: body.quantity,
          quantity: body.quantity,
          amount: body.amount,
          subscription_name: body.type,
        });
      }
      await Profile.findByIdAndUpdate(
        body.profile_id,
        { status: 'paid', payment_type: body.payment_type },
        { new: true }
      );
      // Add subscription history
      return SubscriptionHistory.create({
        amount: body.amount,
        date: body.date,
        type: body.type,
        quantity: body.quantity,
        subscription: subscription._id,
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getSubscribedCourse(id: string): Promise<any> {
    try {
      return await CourseEnroll.find({ subscription: id });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<ISubscription> {
    try {
      return await Subscription.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ISubscription> {
    try {
      return await Subscription.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Subscription.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Subscription.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new SubscriptionService();
