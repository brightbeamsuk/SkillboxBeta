import mongoose, { Schema, Document } from 'mongoose';

export interface ISubscription extends Document {
  subscription_id: string;
  subscription_name: string;
  type: string;
  customer_id: string;
  amount: number;
  quantity: number;
  total_credit: number;
  available_credit: number;
  profile: any;
}

const SubscriptionSchema: Schema = new Schema({
  subscription_id: {
    type: 'String',
    require: false,
  },
  subscription_name: {
    type: 'String',
    require: true,
  },
  type: {
    type: 'String',
    require: true,
  },
  customer_id: {
    type: 'String',
    require: true,
  },
  quantity: {
    type: 'Number',
    require: true,
  },
  amount: {
    type: 'Number',
    require: true,
  },
  total_credit: {
    type: 'Number',
    require: false,
  },
  available_credit: {
    type: 'Number',
    require: false,
  },
  profile: {
    ref: 'Profile',
    type: 'String',
  },
});

export default mongoose.model<ISubscription>(
  'Subscription',
  SubscriptionSchema
);
