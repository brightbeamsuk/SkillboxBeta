import mongoose, { Schema, Document } from 'mongoose';

export interface IOptions extends Document {
  name: string;
  question: string;
}

const OptionsSchema: Schema = new Schema({
  name: {
    type: 'String',
    require: true,
  },
  question: {
    ref: 'Question',
    type: 'ObjectId',
  },
});

export default mongoose.model<IOptions>('Options', OptionsSchema);
