import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/parent/getAll', tokenVerify, controller.parentCourse)
  .get('/child/:id/:profile_id', tokenVerify, controller.childCourse)
  .get('/by_type/:client_id/:type', tokenVerify, controller.courseByType)
  .get('/statistics', tokenVerify, controller.statistics)
  .get('/:id', tokenVerify, controller.show)
  .post('/re-attempt/:course_id/:profile_id', tokenVerify, controller.reAttempt)
  .get(
    '/open-course/:client_id',
    tokenVerify,
    controller.getAvailableOpenCourse
  )
  .get(
    '/completed-courses/:profile_id',
    tokenVerify,
    controller.getCompletedCourse
  )
  .post('/', tokenVerify, controller.store)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/count/all', tokenVerify, controller.count);
