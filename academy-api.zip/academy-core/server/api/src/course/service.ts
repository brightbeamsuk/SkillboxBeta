import { CreateQuery } from 'mongoose';
import Course, { ICourse } from './model';
import CourseEnroll from './../course_enroll/model';
import Chapters from './../chapters/model';
import Quiz from './../quiz/model';
import QuizAttemptLog from './../quiz_attempt_log/model';
import QuizAttempt from './../quiz_attempt/model';
import Certficate, { ICertificate } from './../certificate/model';
import ChaptersRead from './../chapters_read/model';

import L from '../../../common/logger';
export class CourseService {
  async findAll(): Promise<ICourse[]> {
    try {
      return await Course.find().populate('category');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async parentCourse(category, status): Promise<ICourse[]> {
    try {
      const query: any = { parent_id: '' };
      if (category != 'null') {
        query.category = category;
      }
      if (status != 'null' && (status == 'Active' || status == 'Pending')) {
        let published = false;
        if (status == 'Active') {
          published = true;
        } else if (status == 'Pending') {
          published = false;
        }
        query.published = published;
      }
      return await Course.find(query).populate('category');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async childCourse(
    id: string,
    profileId: string,
    _query?: any
  ): Promise<ICourse[]> {
    try {
      const params = {
        parent_id: id,
        published: true,
      };
      if (_query.status === 'All') {
        delete params.published;
      }
      if (
        _query.status != 'null' &&
        (_query.status == 'Active' || _query.status == 'Pending')
      ) {
        let published = false;
        if (_query.status == 'Active') {
          published = true;
        } else if (_query.status == 'Pending') {
          published = false;
        }
        params.published = published;
      }
      const courses = await Course.find(params).populate('category');
      for (const course of courses) {
        course.total_chapter = await Chapters.countDocuments({
          course: course._id,
        });
        const chapterReadCount = await ChaptersRead.countDocuments({
          course: course._id,
          profile: profileId,
        });
        course.total_chapter_read = chapterReadCount;
        course.completed = (chapterReadCount / course.total_chapter) * 100;
      }
      return courses;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getAvailableOpenCourse(clientId: string): Promise<ICourse[]> {
    try {
      const courseIds = [];
      const enrolledCourses = await CourseEnroll.find({
        profile: clientId,
      });
      for (const course of enrolledCourses) {
        courseIds.push(course.course);
      }
      const courses = await Course.find({
        _id: { $nin: courseIds },
        published: true,
      });
      return courses;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getCompletedCourse(profileId: string): Promise<ICertificate[]> {
    try {
      const certificate = Certficate.find({ profile: profileId }).populate(
        'course'
      );
      return certificate;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async courseByType(clientId: string, type: string): Promise<ICourse[]> {
    try {
      const clientAssignedCourseId = [];
      const clientAssignedCourses = await CourseEnroll.find({
        profile: clientId,
      });
      for (const assigned of clientAssignedCourses) {
        clientAssignedCourseId.push(assigned.course);
      }
      return await Course.find({
        _id: { $in: clientAssignedCourseId },
        type,
      }).populate('category');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async statistics(): Promise<ICourse[]> {
    try {
      const details = await Course.aggregate([
        {
          $group: {
            _id: null,
            active_course: {
              $sum: {
                $cond: [{ $eq: ['$published', true] }, 1, 0],
              },
            },
            pending_course: {
              $sum: {
                $cond: [{ $eq: ['$published', false] }, 1, 0],
              },
            },
            free_course: {
              $sum: {
                $cond: [{ $eq: ['$price', 0] }, 1, 0],
              },
            },
            paid_course: {
              $sum: {
                $cond: [{ $gt: ['$price', 0] }, 1, 0],
              },
            },
          },
        },
      ]);
      return details[0];
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICourse> {
    try {
      return await Course.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async reAttempt(id: string, profile: string): Promise<ICourse> {
    try {
      await ChaptersRead.deleteMany({
        profile: profile,
        course: id,
      });
      await Certficate.deleteMany({
        profile: profile,
        course: id,
      });
      const course = await Course.findById(id);
      if (course.type === 'Group') {
        const params = {
          parent_id: id,
          published: true,
        };
        const subCourses = await Course.find(params);
        for (const sCourse of subCourses) {
          await ChaptersRead.deleteMany({
            profile: profile,
            course: sCourse._id,
          });
          await Certficate.deleteMany({
            profile: profile,
            course: sCourse._id,
          });
          const chapters = await Chapters.find({ course: sCourse._id });
          for (const chapter of chapters) {
            const quizzes = await Quiz.find({ chapter: chapter._id });
            for (const quiz of quizzes) {
              await QuizAttemptLog.deleteMany({
                profile: profile,
                quiz: quiz._id,
              });
              await QuizAttempt.deleteMany({
                profile: profile,
                quiz: quiz._id,
              });
            }
          }
        }
      } else {
        const chapters = await Chapters.find({ course: id });
        for (const chapter of chapters) {
          const quizzes = await Quiz.find({ chapter: chapter._id });
          for (const quiz of quizzes) {
            await QuizAttemptLog.deleteMany({
              profile: profile,
              quiz: quiz._id,
            });
            await QuizAttempt.deleteMany({
              profile: profile,
              quiz: quiz._id,
            });
          }
        }
      }
      return course;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICourse>): Promise<ICourse> {
    try {
      const courseCount = await Course.countDocuments({
        title: RegExp('^' + body.title + '$', 'i'),
      });
      if (courseCount > 0) throw new Error('Title already exist');
      return await Course.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<ICourse> {
    try {
      const courseCount = await Course.countDocuments({
        _id: { $ne: id },
        title: RegExp('^' + body.title + '$', 'i'),
      });
      if (courseCount > 0) throw new Error('Title already exist');
      return await Course.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICourse> {
    try {
      await CourseEnroll.deleteMany({ course: id });
      return await Course.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Course.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Course.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CourseService();
