import mongoose, { Schema, Document } from 'mongoose';
import { ICertificate } from './../certificate/model';
import { ICourseEnroll } from './../course_enroll/model';
export interface ICourse extends Document {
  title: 'string';
  description: 'string';
  price: 'number';
  discount: 'number';
  validity: 'number';
  cpd_points: 'number';
  cpd_bal_points: 'number';
  assessor: 'string';
  image: 'string';
  parent_id?: string;
  type: string;
  published: boolean;
  total_chapter?: number;
  total_chapter_read?: number;
  completed?: number;
  course_completed?: boolean;
  category?: any;
  enroll?: ICourseEnroll;
  certificate?: ICertificate;
  groupCourses?: ICourse[];
}

const CourseSchema: Schema = new Schema({
  title: {
    type: 'String',
    require: true,
  },
  description: {
    type: 'String',
    require: false,
  },
  price: {
    type: 'Number',
    require: false,
  },
  discount: {
    type: 'Number',
    require: true,
  },
  validity: {
    type: 'Number',
    require: false,
  },
  cpd_points: {
    type: 'Number',
    require: false,
  },
  cpd_bal_points: {
    type: 'Number',
    require: false,
  },
  assessor: {
    type: 'String',
    require: false,
  },
  image: {
    type: 'String',
    require: true,
  },
  type: {
    type: 'String',
    require: true,
  },
  published: {
    type: 'Boolean',
    require: true,
  },
  parent_id: {
    require: false,
    type: 'String',
  },
  total_chapter: {
    type: 'Number',
    require: false,
  },
  completed: {
    type: 'Number',
    require: false,
  },
  course_completed: {
    type: 'Boolean',
    require: false,
  },
  total_chapter_read: {
    type: 'Number',
    require: false,
  },
  enroll: {
    type: 'Object',
    require: false,
  },
  certificate: {
    type: 'Object',
    require: false,
  },
  groupCourses: {
    type: 'Object',
    require: false,
  },
  category: {
    ref: 'CourseCategory',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICourse>('Course', CourseSchema);
