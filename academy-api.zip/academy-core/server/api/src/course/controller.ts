import CourseService from './service';
import { Request, Response } from 'express';
export class Controller {
  /**
   * List all records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  index(req: Request, res: Response): void {
    CourseService.findAll().then((r) => res.json(r));
  }

  /**
   * List all parent records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  parentCourse(req: Request, res: Response): void {
    const category = req.query.category as string;
    const status = req.query.status as string;
    CourseService.parentCourse(category, status).then((r) => res.json(r));
  }

  /**
   * List all child records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  childCourse(req: Request, res: Response): void {
    const id = req.params['id'];
    const profileId = req.params['profile_id'];
    const query = req.query;
    CourseService.childCourse(id, profileId, query).then((r) => res.json(r));
  }

  /**
   * List all course by type records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  courseByType(req: Request, res: Response): void {
    const id = req.params['client_id'];
    const type = req.params['type'];
    CourseService.courseByType(id, type).then((r) => res.json(r));
  }

  /**
   * List course statistics
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  statistics(req: Request, res: Response): void {
    CourseService.statistics().then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  show(req: Request, res: Response): void {
    const id = req.params['id'];
    CourseService.findById(id).then((r) => res.json(r));
  }

  /**
   * Reattempt course
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  reAttempt(req: Request, res: Response): void {
    const id = req.params['course_id'];
    const profile = req.params['profile_id'];
    CourseService.reAttempt(id, profile).then((r) => res.json(r));
  }

  /**
   * Open courses
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  getAvailableOpenCourse(req: Request, res: Response): void {
    const profile = req.params['client_id'];
    CourseService.getAvailableOpenCourse(profile).then((r) => res.json(r));
  }

  /**
   * Completed courses
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  getCompletedCourse(req: Request, res: Response): void {
    const profile = req.params['profile_id'];
    CourseService.getCompletedCourse(profile).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  store(req: Request, res: Response): void {
    const body = req.body;
    CourseService.create(body).then((r) => res.json(r));
  }

  /**
   * Update record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  update(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['id'];
    CourseService.update(body, id).then((r) => res.json(r));
  }

  /**
   * Delete record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  delete(req: Request, res: Response): void {
    const id = req.params['id'];
    CourseService.deleteById(id).then((r) => res.json(r));
  }

  /**
   * Delete all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  deleteAll(req: Request, res: Response): void {
    CourseService.deleteAll().then((r) => res.json(r));
  }

  /**
   * Count all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  count(req: Request, res: Response): void {
    CourseService.count().then((r) => res.json(r));
  }
}

export default new Controller();
