import ProfileService from './service';
import { Request, Response } from 'express';
export class Controller {
  /**
   * List all records
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  index(req: Request, res: Response): void {
    ProfileService.findAll().then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  show(req: Request, res: Response): void {
    const id = req.params['id'];
    ProfileService.findById(id).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  getProfilesBySlug(req: Request, res: Response): void {
    const slug = req.params['slug'];
    ProfileService.getProfilesBySlug(slug).then((r) => res.json(r));
  }

  /**
   * Fetch record using the diven :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  getProfileByUserId(req: Request, res: Response): void {
    const userId = req.params['user_id'];
    ProfileService.getProfileByUserId(userId).then((r) => res.json(r));
  }

  /**
   * Create new record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  store(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.create(body).then((r) => res.json(r));
  }

  /**
   * Create new candidate record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  createCandidate(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['client_id'];
    ProfileService.createCandidate(body, id).then((r) => res.json(r));
  }

  /**
   * Create new candidate record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  createUser(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['client_id'];
    ProfileService.createUser(body, id).then((r) => res.json(r));
  }
  /**
   * Create new Client record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  createClient(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.createClient(body).then((r) => res.json(r));
  }

  /**
   * Send email
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  sendEmail(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.sendEmail(body).then((r) => res.json(r));
  }

  /**
   * Send email
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  resendCredentials(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.resendCredentials(body).then((r) => res.json(r));
  }

  /**
   * Activate Deactivate profile and user
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  activateDeactivate(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['id'];
    ProfileService.activateDeactivate(body, id).then((r) => res.json(r));
  }

  /**
   * Delete candidate
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  deleteCandidates(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.deleteCandidates(body).then((r) => res.json(r));
  }

  /**
   * Update record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  update(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['id'];
    ProfileService.update(body, id).then((r) => res.json(r));
  }

  /**
   * Delete record with :id
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  delete(req: Request, res: Response): void {
    const id = req.params['id'];
    ProfileService.deleteById(id).then((r) => res.json(r));
  }

  /**
   * Delete all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  deleteAll(req: Request, res: Response): void {
    ProfileService.deleteAll().then((r) => res.json(r));
  }

  /**
   * Count all record
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  count(req: Request, res: Response): void {
    ProfileService.count().then((r) => res.json(r));
  }

  /**
   * List client statistics
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  statistics(req: Request, res: Response): void {
    ProfileService.statistics().then((r) => res.json(r));
  }

  /**
   * List client statistics
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  clientDashboardStatistics(req: Request, res: Response): void {
    const id = req.params['client_id'];
    ProfileService.clientDashboardStatistics(id).then((r) => res.json(r));
  }

  /**
   * List client statistics
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  adminDashboardStatistics(req: Request, res: Response): void {
    ProfileService.adminDashboardStatistics().then((r) => res.json(r));
  }

  /**
   * List client statistics
   *
   * @param   {Request}   req  [req description]
   * @param   {Response}  res  [res description]
   *
   * @return  {void}           [return description]
   */
  clientMatrix(req: Request, res: Response): void {
    const id = req.params['profile_id'];
    const courseIds = req.query.course_ids as string;
    ProfileService.clientMatrix(id, courseIds).then((r) => res.json(r));
  }

  uploadCandidates(req: Request, res: Response): void {
    ProfileService.uploadCandidates(req).then((r) => res.json(r));
  }

  importCandidates(req: Request, res: Response): void {
    const body = req.body;
    const id = req.params['client_id'];
    ProfileService.importCandidates(body, id).then((r) => res.json(r));
  }

  testAPIForMailGunResponce(req: Request, res: Response): void {
    const body = req.body;
    ProfileService.testAPIForMailGunResponce(body).then((r) => res.json(r));
  }
}

export default new Controller();
