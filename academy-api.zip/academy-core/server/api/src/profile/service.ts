import { CreateQuery } from 'mongoose';
import * as crypto from 'crypto';
import csvtojson from 'csvtojson';
import moment from 'moment';

import Profile, { IProfile } from './model';
import User from './../users/model';
import ProfileType from './../profile_type/model';
import ClientUsers from './../client_users/model';
import PlanDetails from './../plan_details/model';
import ClientPlanDetails from './../client_plan_details/model';
import Course from './../course/model';
import Chapters from './../chapters/model';
import ChaptersRead from './../chapters_read/model';
import CourseEnroll from './../course_enroll/model';
import Certificate from './../certificate/model';
import GroupCandidates from './../group_candidates/model';
import Subscription, { ISubscription } from './../subscription/model';
import L from '../../../common/logger';
import MailGun from '../../../common/email/mail.gun';
import UserService from './../users/service';
import ClientUser from './../client_users/model';
import EmailTemplates from './../emailtemplates/service';
interface MulterRequest extends Request {
  files: any;
}
export class ProfileService {
  async findAll(): Promise<IProfile[]> {
    try {
      return await Profile.find()
        .populate('user')
        .populate('profile_type')
        .populate('address');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IProfile> {
    try {
      const profile = await Profile.findById(id).populate('address');
      const subscription = await Subscription.findOne({ profile: profile._id });
      console.log('subscription', subscription);
      profile.subscription = subscription;
      return profile;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getProfilesBySlug(slug: any): Promise<IProfile[]> {
    try {
      const profileType = await ProfileType.findOne({ slug });
      if (!profileType)
        throw new Error(`Profile type ${slug} not exist with slug carer`);
      const profiles = await Profile.find({
        profile_type: profileType._id,
      })
        .populate('profile_type')
        .populate('address');
      return profiles;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getProfileByUserId(userId: string): Promise<IProfile> {
    try {
      return await Profile.findOne({ user: userId })
        .populate('profile_type')
        .populate('address');
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IProfile>): Promise<IProfile> {
    try {
      return await Profile.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createCandidate(
    body: CreateQuery<IProfile>,
    clientId: string
  ): Promise<IProfile> {
    try {
      const userName = body.email.toString();
      const email = body.email.toString();
      const password =
        body.first_name.substring(0, 3) +
        body.last_name.substring(0, 3) +
        Math.floor(Math.random() * (999 - 100 + 1) + 100);
      const encryptionKey = process.env.ENCRYPTION_KEY as string;
      const hash = crypto.createHmac('sha512', encryptionKey).update(password);
      const hashedPass = hash.digest('hex').toString();

      try {
        let user: any = '';
        if (userName) {
          user = await User.findOne({ user_name: userName });
        }

        if (email) {
          user = await User.findOne({ email: email });
        }
        if (user instanceof Error) {
          throw new Error('Something went wrong');
        }

        if (!user) {
          const dbUserParams = {
            password: hashedPass,
            email: email,
            user_name: userName,
            date_created: Date().toString(),
            enabled: 1,
          };
          // Create user
          const responce = await User.create(dbUserParams);
          if (responce instanceof Error) {
            throw new Error('Error while creating user.');
          }
          // Create profile
          body.user = responce._id;
          const profile = await Profile.create(body);
          profile.password = password;

          // Candidate mapping with client
          await ClientUsers.create({
            client_profile: clientId,
            profile: profile._id,
          });
          // Send login credentials
          if (body.send_login) {
            const content = {
              user_name: userName,
              password,
              full_name: `${profile.first_name} ${profile.last_name}`,
            };
            const subject = 'Your account has been created';
            const templateId = 'new-candidate-create';
            const from = `${process.env.MAIL_GUN_FROM_NAME} <${process.env.MAIL_GUN_FROM_EMAIL}>`;
            MailGun.send(from, email, subject, templateId, content);
            return profile;
          }
          return profile;
        } else {
          throw new Error(
            'Unable to add user, because the userName, and or, email address is already associated with an existing account.'
          );
        }
      } catch (error) {
        if (error) {
          return error.message;
        }
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async resendCredentials(body: any): Promise<boolean> {
    try {
      for (const profileId of body.profileIds) {
        const profile = await Profile.findOne({ _id: profileId });
        if (profile) {
          const password =
            profile.first_name.substring(0, 3) +
            profile.last_name.substring(0, 3) +
            Math.floor(Math.random() * (999 - 100 + 1) + 100);
          const encryptionKey = process.env.ENCRYPTION_KEY as string;
          const hash = crypto
            .createHmac('sha512', encryptionKey)
            .update(password);
          const hashedPass = hash.digest('hex').toString();
          await User.findByIdAndUpdate(profile.user, {
            user_name: profile.email,
            password: hashedPass,
          });
          const from = `${process.env.MAIL_GUN_FROM_NAME} <${process.env.MAIL_GUN_FROM_EMAIL}>`;
          const content = {
            user_name: profile.email,
            password: password,
            full_name: `${profile.first_name} ${profile.last_name}`,
          };
          const subject = 'Your academy account details';
          const templateId = 'new-candidate-create';
          const to = profile.email;
          await MailGun.send(from, to, subject, templateId, content);
        }
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createUser(
    body: CreateQuery<IProfile>,
    clientId: string
  ): Promise<IProfile> {
    try {
      const userName = body.email.toString();
      const email = body.email.toString();
      const password =
        body.first_name.substring(0, 3) +
        body.last_name.substring(0, 3) +
        Math.floor(Math.random() * (999 - 100 + 1) + 100);
      const encryptionKey = process.env.ENCRYPTION_KEY as string;
      const hash = crypto.createHmac('sha512', encryptionKey).update(password);
      const hashedPass = hash.digest('hex').toString();

      try {
        let user: any = '';
        if (userName) {
          user = await User.findOne({ user_name: userName });
        }

        if (email) {
          user = await User.findOne({ email: email });
        }
        if (user instanceof Error) {
          throw new Error('Something went wrong');
        }

        if (user)
          throw new Error(
            'Unable to add user, because the userName, and or, email address is already associated with an existing account.'
          );
        const dbUserParams = {
          password: hashedPass,
          email: email,
          user_name: userName,
          date_created: Date().toString(),
          enabled: 1,
        };
        const responce = await User.create(dbUserParams);
        if (responce instanceof Error) {
          throw new Error('Error while creating user.');
        }
        if (!body.profile_type) {
          const profileType = await ProfileType.findOne({
            slug: 'system_users',
          });
          if (profileType) {
            body.profile_type = profileType._id;
          }
        }
        body.user = responce._id;
        const clientprofile = await Profile.findById(clientId);
        body.address = clientprofile.address;
        const profile = await Profile.create(body);

        // User mapping with client
        await ClientUsers.create({
          client_profile: clientId,
          profile: profile._id,
        });

        if (body.send_login) {
          const content = {
            user_name: userName,
            password,
            full_name: `${profile.first_name} ${profile.last_name}`,
          };
          const subject = 'Your account has been created';
          const templateId = 'new-client-create';
          const from = `${process.env.MAIL_GUN_FROM_NAME} <${process.env.MAIL_GUN_FROM_EMAIL}>`;
          MailGun.send(from, email, subject, templateId, content);
          return profile;
        }
        return profile;
      } catch (error) {
        if (error) {
          return error.message;
        }
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async createClient(body: CreateQuery<IProfile>): Promise<IProfile> {
    try {
      console.log('body', body);
      const userName = body.email.toString();
      const email = body.email.toString();
      const password =
        body.first_name.substring(0, 3) +
        body.last_name.substring(0, 3) +
        Math.floor(Math.random() * (999 - 100 + 1) + 100);
      const encryptionKey = process.env.ENCRYPTION_KEY as string;
      const hash = crypto.createHmac('sha512', encryptionKey).update(password);
      const hashedPass = hash.digest('hex').toString();

      try {
        let user: any = '';
        if (userName) {
          user = await User.findOne({ user_name: userName });
        }

        if (email) {
          user = await User.findOne({ email: email });
        }
        if (user instanceof Error) {
          throw new Error('Something went wrong');
        }

        if (user)
          throw new Error(
            'Unable to add user, because the userName, and or, email address is already associated with an existing account.'
          );
        const dbUserParams = {
          password: hashedPass,
          email: email,
          user_name: userName,
          date_created: Date().toString(),
          enabled: 1,
        };
        const responce = await User.create(dbUserParams);
        if (responce instanceof Error) {
          throw new Error('Error while creating user.');
        }
        if (!body.profile_type) {
          const profileType = await ProfileType.findOne({ slug: 'client' });
          if (profileType) {
            body.profile_type = profileType._id;
          }
        }
        body.user = responce._id;
        const profile = await Profile.create(body);

        // Create default course complete template
        await EmailTemplates.createEmailTemplate(profile._id);

        // Create default plan
        const planDetails = await PlanDetails.find();
        for (const planDetail of planDetails) {
          const data = {
            limit_from: planDetail.limit_from,
            limit_to: planDetail.limit_to,
            price: planDetail.price,
            plan: planDetail.plan,
            profile: profile._id,
          };
          await ClientPlanDetails.create(data);
        }
        if (body.send_login) {
          const content = {
            user_name: userName,
            password,
            full_name: `${profile.first_name} ${profile.last_name}`,
          };
          const subject = 'Your account has been created';
          const templateId = 'new-client-create';
          const from = `${process.env.MAIL_GUN_FROM_NAME} <${process.env.MAIL_GUN_FROM_EMAIL}>`;
          MailGun.send(from, email, subject, templateId, content);
          return profile;
        }
        return profile;
      } catch (error) {
        if (error) {
          return error.message;
        }
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async sendEmail(body: any): Promise<boolean> {
    try {
      const content = body.content;
      const subject = body.subject;
      const templateId = body.templateId;
      const from = body.from;
      const to = body.to;
      MailGun.send(from, to, subject, templateId, content);
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async activateDeactivate(body: any, id: string): Promise<IProfile> {
    try {
      const profile = await Profile.findByIdAndUpdate(id, body, { new: true });
      await User.findByIdAndUpdate(profile.user, {
        user_name: body.email,
        enabled: body.is_active,
      });
      return profile;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteCandidates(body: any): Promise<ISubscription> {
    try {
      const profile = await Profile.findById(body.profileId);
      await User.findByIdAndDelete(profile.user);
      const clientUser = await ClientUser.findOne({
        client_profile: body.clientId,
        profile: body.profileId,
      });
      clientUser.remove();
      const subscription = await Subscription.findById(body.subscriptionId);
      if (subscription) {
        subscription.available_credit = subscription.available_credit + 1;
      }
      const newSubscription = await Subscription.findByIdAndUpdate(
        subscription._id,
        subscription,
        {
          new: true,
        }
      );
      profile.remove();
      return newSubscription;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IProfile> {
    try {
      const profile = await Profile.findByIdAndUpdate(id, body, { new: true });
      const user = await User.findById(profile.user._id);
      user.email = profile.email;
      user.user_name = profile.email;
      await User.findByIdAndUpdate(user._id, user, { new: true });
      return profile;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IProfile> {
    try {
      return await Profile.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await Profile.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await Profile.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async statistics(): Promise<IProfile[]> {
    try {
      const slug: any = 'client';
      const profileType = await ProfileType.findOne({ slug: slug });
      const details = await Profile.aggregate([
        {
          $group: {
            _id: null,
            no_of_clients: {
              $sum: {
                $cond: [{ $eq: ['$profile_type', profileType._id] }, 1, 0],
              },
            },
            active_clients: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      { $eq: ['$is_active', true] },
                      { $eq: ['$profile_type', profileType._id] },
                    ],
                  },
                  1,
                  0,
                ],
              },
            },
            inactive_clients: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      { $eq: ['$is_active', false] },
                      { $eq: ['$profile_type', profileType._id] },
                    ],
                  },
                  1,
                  0,
                ],
              },
            },
            expired_clients: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      { $eq: ['$status', 'expired'] },
                      { $eq: ['$profile_type', profileType._id] },
                    ],
                  },
                  1,
                  0,
                ],
              },
            },
          },
        },
      ]);
      return details[0];
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async clientDashboardStatistics(clientId: string): Promise<any> {
    const responce: any = {
      totalCredit: 0,
      availableCredit: 0,
      totalCandidates: 0,
      totalCourse: 0,
      activeCandidates: 0,
      unpublishedCourse: 0,
      subscriptionType: '',
      quantity: 0,
      amount: 0,
    };
    try {
      const subscription = await Subscription.find({ profile: clientId })
        .sort({ _id: -1 })
        .limit(1);
      if (subscription.length > 0) {
        responce.totalCredit = subscription[0].total_credit;
        responce.availableCredit = subscription[0].available_credit;
        responce.subscriptionType = subscription[0].type;
        responce.quantity = subscription[0].quantity;
        responce.amount = subscription[0].amount;
      }
      const profileType = await ProfileType.findOne({ slug: 'candidate' });
      const candidates = await ClientUsers.find({
        client_profile: clientId,
      }).populate('profile');
      const candidateIds = [];
      for (const candidate of candidates) {
        if (
          candidate.profile &&
          candidate.profile.profile_type.equals(profileType._id)
        ) {
          candidateIds.push(candidate.profile._id);
        }
      }
      responce.totalCandidates = candidateIds.length;
      const activeCandidatesCount = await Profile.countDocuments({
        _id: { $in: candidateIds },
        is_active: true,
      });
      responce.activeCandidates = activeCandidatesCount;
      const enrolledCourses = await CourseEnroll.find({
        profile: clientId,
      });
      const courseIds = [];
      for (const course of enrolledCourses) {
        courseIds.push(course.course);
      }
      responce.totalCourse = enrolledCourses.length;
      const unPublishedCount = await Course.countDocuments({
        _id: { $in: courseIds },
        published: false,
      });
      responce.unpublishedCourse = unPublishedCount;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
    return responce;
  }

  async adminDashboardStatistics(): Promise<any> {
    try {
      const clientProfileType = await ProfileType.findOne({ slug: 'client' });
      const candidateProfileType = await ProfileType.findOne({
        slug: 'candidate',
      });
      const noOfClients = await Profile.countDocuments({
        profile_type: clientProfileType._id,
      });
      const noOfCandidates = await Profile.countDocuments({
        profile_type: candidateProfileType._id,
      });
      const noOfCourse = await Course.countDocuments();
      return {
        clients: noOfClients,
        candidates: noOfCandidates,
        course: noOfCourse,
      };
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async clientMatrix(id: string, courseIds: string): Promise<any> {
    try {
      const output = [];
      const clientAssignedCourseId = [];
      const params = {
        profile: id,
      };
      if (courseIds) {
        params['course'] = { $in: courseIds.split(',') };
      }
      const clientAssignedCourses = await CourseEnroll.find(params);
      for (const assigned of clientAssignedCourses) {
        clientAssignedCourseId.push(assigned.course);
      }
      const candidateId = [];
      const courseStartedCandidatesId = [];
      const clientUsers = await ClientUsers.find({
        client_profile: id,
      });
      for (const candidate of clientUsers) {
        candidateId.push(candidate.profile);
        const enroll = await CourseEnroll.findOne({
          profile: candidate.profile,
          started: true,
        });
        if (enroll) {
          courseStartedCandidatesId.push(candidate.profile);
        }
      }
      const candidates = await Profile.find({
        _id: { $in: courseStartedCandidatesId },
      });
      for (const candidate of candidates) {
        const group = await GroupCandidates.findOne({
          candidate: candidate._id,
        }).populate('group');
        const courses = await Course.find({
          _id: { $in: clientAssignedCourseId },
          published: true,
        });
        const res = { candidate: candidate, group: group, courses: [] };
        for (const course of courses) {
          if (course.type === 'Single') {
            const chapters = await Chapters.find({ course: course._id });
            const chapterRead = await ChaptersRead.find({
              profile: candidate._id,
              course: course._id,
            });
            course.total_chapter = chapters.length;
            course.total_chapter_read = chapterRead.length;
            const enroll = await CourseEnroll.findOne({
              profile: candidate._id,
              course: course._id,
            });
            course.enroll = enroll;
            const certificate = await Certificate.findOne({
              profile: candidate._id,
              course: course._id,
            });
            if (certificate) {
              const dateofvisit = moment(certificate.exp_date, 'DD-MM-YYYY');
              const today = moment();
              certificate.remaining_days = dateofvisit.diff(today, 'days');
            }
            course.certificate = certificate;
            res.courses.push(course);
          } else {
            const groupCourses = await Course.find({
              parent_id: course._id,
              published: true,
            });
            for (const gCourse of groupCourses) {
              const chapters = await Chapters.find({ course: gCourse._id });
              const chapterRead = await ChaptersRead.find({
                profile: candidate._id,
                course: gCourse._id,
              });
              gCourse.total_chapter = chapters.length;
              gCourse.total_chapter_read = chapterRead.length;
              const enroll = await CourseEnroll.findOne({
                profile: candidate._id,
                course: gCourse._id,
              });
              gCourse.enroll = enroll;
              const certificate = await Certificate.findOne({
                profile: candidate._id,
                course: gCourse._id,
              });
              if (certificate) {
                const dateofvisit = moment(certificate.exp_date, 'DD-MM-YYYY');
                const today = moment();
                certificate.remaining_days = dateofvisit.diff(today, 'days');
              }
              gCourse.certificate = certificate;
            }
            course.groupCourses = groupCourses;
            res.courses.push(course);
          }
        }
        output.push(res);
      }
      return output;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async uploadCandidates(req: any): Promise<any> {
    const csvFilePath = (req as MulterRequest).files.file.path;
    try {
      const jsonArray = await csvtojson().fromFile(csvFilePath);
      for (const result of jsonArray) {
        const profile = await Profile.findOne({ email: result.email });
        if (profile) {
          result.exist = true;
        }
      }
      return jsonArray;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async importCandidates(datas: any, clientId: string): Promise<any> {
    try {
      const profileType = await ProfileType.findOne({ slug: 'candidate' });
      const candidates = datas.candidates;
      const courses = datas.courses;
      for (const data of candidates) {
        const payload = {
          first_name: data.first_name,
          last_name: data.last_name,
          email: data.email,
          phone: data.phone,
          send_login: true,
          certificate_access: true,
          status: 'Active',
          profile_image: '',
          is_active: true,
          profile_type: profileType._id,
          created_by: '',
        };
        const profile = await this.createCandidate(payload, clientId);
        for (const course of courses) {
          await CourseEnroll.create({
            profile: profile._id,
            course: course,
          });
        }
      }
      return true;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async testAPIForMailGunResponce(data: any): Promise<any> {
    try {
      console.log('data from mail gun', data);
      console.log(data.message.headers);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ProfileService();
