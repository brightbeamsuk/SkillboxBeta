import mongoose, { Schema, Document } from 'mongoose';
import { ICourse } from './../course/model';
import { ISubscription } from './../subscription/model';
export interface IProfile extends Document {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  profile_image: string;
  client_logo?: string;
  client_name?: string;
  certificate_access: boolean;
  created_by?: string;
  status: string;
  payment_type?: string;
  is_active: boolean;
  send_login?: boolean;
  total_course?: number;
  password?: string;
  courses?: ICourse[];
  user?: any;
  profile_type?: any;
  address?: any;
  subscription?: ISubscription;
}

const ProfileSchema: Schema = new Schema({
  first_name: {
    type: 'String',
    require: true,
  },
  last_name: {
    type: 'String',
    require: true,
  },
  email: {
    type: 'String',
    require: true,
  },
  phone: {
    type: 'String',
    require: false,
  },
  profile_image: {
    type: 'String',
    require: false,
  },
  client_logo: {
    type: 'String',
    require: false,
  },
  client_name: {
    type: 'String',
    require: false,
  },
  status: {
    type: 'String',
    require: true,
  },
  certificate_access: {
    type: 'Boolean',
    require: true,
  },
  is_active: {
    type: 'Boolean',
    require: true,
  },
  total_course: {
    type: 'Number',
    require: false,
  },
  password: {
    type: 'String',
    require: false,
  },
  created_by: {
    type: 'String',
    require: true,
  },
  payment_type: {
    type: 'String',
    require: false,
  },
  courses: {
    type: 'Object',
    require: false,
  },
  profile_type: {
    ref: 'ProfileType',
    type: 'ObjectId',
  },
  subscription: {
    type: 'Object',
    require: false,
  },
  address: {
    ref: 'Address',
    type: 'ObjectId',
  },
  user: {
    ref: 'User',
    type: 'ObjectId',
  },
});

export default mongoose.model<IProfile>('Profile', ProfileSchema);
