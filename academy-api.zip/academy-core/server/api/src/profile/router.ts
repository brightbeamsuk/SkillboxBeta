import express from 'express';
import controller from './controller';
import tokenVerify from './../../middlewares/token.verify';
export default express
  .Router()
  .get('/', tokenVerify, controller.index)
  .get('/:id', tokenVerify, controller.show)
  .get('/type/:slug', tokenVerify, controller.getProfilesBySlug)
  .get('/details/:user_id', tokenVerify, controller.getProfileByUserId)
  .post('/', tokenVerify, controller.store)
  .post('/client/create', controller.createClient)
  .post('/candidate/create/:client_id', tokenVerify, controller.createCandidate)
  .post('/user/create/:client_id', tokenVerify, controller.createUser)
  .post('/resend_credentials', tokenVerify, controller.resendCredentials)
  .post('/delete_candidate', tokenVerify, controller.deleteCandidates)
  .post('/send_email', tokenVerify, controller.sendEmail)
  .post('/activate_deactive/:id', tokenVerify, controller.activateDeactivate)
  .put('/:id', tokenVerify, controller.update)
  .delete('/:id', tokenVerify, controller.delete)
  .delete('/', tokenVerify, controller.deleteAll)
  .get('/client/statistics', tokenVerify, controller.statistics)
  .get(
    '/client/dashboard/statistics/:client_id',
    tokenVerify,
    controller.clientDashboardStatistics
  )
  .get(
    '/admin/dashboard/statistics',
    tokenVerify,
    controller.adminDashboardStatistics
  )
  .get('/client/matrix/:profile_id', tokenVerify, controller.clientMatrix)
  .post('/client/upload-candidates', tokenVerify, controller.uploadCandidates)
  .post(
    '/client/import-candidates/:client_id',
    tokenVerify,
    controller.importCandidates
  )
  .get('/count/all', tokenVerify, controller.count)
  .post('/mail-gun-responce', controller.testAPIForMailGunResponce);
