import { CreateQuery } from 'mongoose';
import QuizAttempt, { IQuizAttempt } from './model';
import L from '../../../common/logger';
export class QuizAttemptService {
  async findAll(): Promise<IQuizAttempt[]> {
    try {
      return await QuizAttempt.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IQuizAttempt> {
    try {
      return await QuizAttempt.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IQuizAttempt>): Promise<IQuizAttempt> {
    try {
      return await QuizAttempt.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IQuizAttempt> {
    try {
      return await QuizAttempt.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IQuizAttempt> {
    try {
      return await QuizAttempt.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await QuizAttempt.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await QuizAttempt.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new QuizAttemptService();
