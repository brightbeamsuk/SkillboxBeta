import mongoose, { Schema, Document } from 'mongoose';

export interface IQuizAttempt extends Document {
  mark: number;
  correct: number;
  wrong: number;
  status: string;
  quiz?: string;
  profile?: string;
}

const QuizAttemptSchema: Schema = new Schema({
  mark: {
    type: 'Number',
    require: false,
  },
  correct: {
    type: 'Number',
    require: false,
  },
  wrong: {
    type: 'Number',
    require: false,
  },
  status: {
    type: 'String',
    require: true,
  },
  quiz: {
    ref: 'Quiz',
    type: 'ObjectId',
  },
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<IQuizAttempt>('QuizAttempt', QuizAttemptSchema);
