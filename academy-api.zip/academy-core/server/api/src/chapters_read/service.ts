import { CreateQuery } from 'mongoose';
import ChaptersRead, { IChaptersRead } from './model';
import CourseEnroll from './../course_enroll/model';
import L from '../../../common/logger';
export class ChaptersReadService {
  async findAll(): Promise<IChaptersRead[]> {
    try {
      return await ChaptersRead.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IChaptersRead> {
    try {
      return await ChaptersRead.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IChaptersRead>): Promise<IChaptersRead> {
    try {
      const read = await ChaptersRead.findOne({
        chapter: body.chapter,
        course: body.course,
        profile: body.profile,
      });
      const courseEnroll = await CourseEnroll.findOne({
        profile: body.profile,
        course: body.course,
      });
      if (courseEnroll && !courseEnroll.started) {
        courseEnroll.started = true;
        await CourseEnroll.findByIdAndUpdate(courseEnroll._id, courseEnroll);
      }
      if (!read) {
        return await ChaptersRead.create(body);
      } else {
        return read;
      }
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IChaptersRead>,
    id: string
  ): Promise<IChaptersRead> {
    try {
      return await ChaptersRead.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IChaptersRead> {
    try {
      return await ChaptersRead.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ChaptersRead.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ChaptersRead.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ChaptersReadService();
