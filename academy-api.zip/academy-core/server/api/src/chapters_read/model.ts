import mongoose, { Schema, Document } from 'mongoose';
export interface IChaptersRead extends Document {
  profile?: string;
  course?: string;
  chapter?: string;
}

const ChaptersReadSchema: Schema = new Schema({
  profile: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
  chapter: {
    ref: 'Chapters',
    type: 'ObjectId',
  },
});

export default mongoose.model<IChaptersRead>(
  'ChaptersRead',
  ChaptersReadSchema
);
