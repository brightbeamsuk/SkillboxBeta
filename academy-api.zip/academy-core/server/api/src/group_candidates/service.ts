import { CreateQuery } from 'mongoose';
import GroupCandidates, { IGroupCandidates } from './model';
import L from '../../../common/logger';
export class GroupCandidatesService {
  async findAll(): Promise<IGroupCandidates[]> {
    try {
      return await GroupCandidates.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IGroupCandidates> {
    try {
      return await GroupCandidates.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<IGroupCandidates>): Promise<IGroupCandidates> {
    try {
      return await GroupCandidates.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async multiple(
    body: CreateQuery<IGroupCandidates[]>
  ): Promise<IGroupCandidates> {
    try {
      return await GroupCandidates.insertMany(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<IGroupCandidates> {
    try {
      return await GroupCandidates.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IGroupCandidates> {
    try {
      return await GroupCandidates.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await GroupCandidates.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await GroupCandidates.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new GroupCandidatesService();
