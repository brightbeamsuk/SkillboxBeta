import mongoose, { Schema, Document } from 'mongoose';
import { IProfile } from './../profile/model';
export interface IGroupCandidates extends Document {
  enabled: 'boolean';
  candidates: IProfile[];
  candidate: string;
}

const GroupCandidatesSchema: Schema = new Schema({
  enabled: {
    type: 'Boolean',
    require: false,
  },
  candidates: {
    type: 'Object',
    require: false,
  },
  candidate: {
    ref: 'Profile',
    type: 'ObjectId',
  },
  group: {
    ref: 'CandidateGroup',
    type: 'ObjectId',
  },
});

export default mongoose.model<IGroupCandidates>(
  'GroupCandidates',
  GroupCandidatesSchema
);
