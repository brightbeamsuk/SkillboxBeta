import mongoose, { Schema, Document } from 'mongoose';

export type IComboCourseMapping = Document;

const ComboCourseMappingSchema: Schema = new Schema({
  combo: {
    ref: 'ComboCourse',
    type: 'ObjectId',
  },
  course: {
    ref: 'Course',
    type: 'ObjectId',
  },
});

export default mongoose.model<IComboCourseMapping>(
  'ComboCourseMapping',
  ComboCourseMappingSchema
);
