import { CreateQuery } from 'mongoose';
import ComboCourseMapping, { IComboCourseMapping } from './model';
import L from '../../../common/logger';
export class ComboCourseMappingService {
  async findAll(): Promise<IComboCourseMapping[]> {
    try {
      return await ComboCourseMapping.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<IComboCourseMapping> {
    try {
      return await ComboCourseMapping.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(
    body: CreateQuery<IComboCourseMapping>
  ): Promise<IComboCourseMapping> {
    try {
      return await ComboCourseMapping.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(
    body: CreateQuery<IComboCourseMapping>,
    id: string
  ): Promise<IComboCourseMapping> {
    try {
      return await ComboCourseMapping.findByIdAndUpdate(id, body, {
        new: true,
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<IComboCourseMapping> {
    try {
      return await ComboCourseMapping.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await ComboCourseMapping.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await ComboCourseMapping.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new ComboCourseMappingService();
