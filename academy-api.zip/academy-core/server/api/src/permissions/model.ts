import mongoose, { Schema, Document } from 'mongoose';

export interface IPermissions extends Document {
  type: 'string';
}

const PermissionsSchema: Schema = new Schema({
  type: {
    type: 'String',
    require: true,
  },
});

export default mongoose.model<IPermissions>('Permissions', PermissionsSchema);
