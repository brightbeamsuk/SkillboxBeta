import { CreateQuery } from 'mongoose';
import CandidateGroup, { ICandidateGroup } from './model';
import GroupCandidates from './../group_candidates/model';
import Profile, { IProfile } from './../profile/model';
import IClientUsers from './../client_users/model';
import L from '../../../common/logger';
export class CandidateGroupService {
  async findAll(): Promise<ICandidateGroup[]> {
    try {
      return await CandidateGroup.find();
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async findById(id: string): Promise<ICandidateGroup> {
    try {
      return await CandidateGroup.findById(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async byClient(id: string): Promise<ICandidateGroup[]> {
    try {
      const groups = await CandidateGroup.find({ client: id });
      for (const group of groups) {
        const candidates = await GroupCandidates.countDocuments({
          group: group._id,
        });
        group.total_candidates = candidates;
      }
      return groups;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async getCandidates(id: string): Promise<IProfile[]> {
    try {
      const groupsCandidates = await GroupCandidates.find({ group: id });
      const candidates = [];
      for (const gc of groupsCandidates) {
        const profile = await Profile.findById(gc.candidate);
        candidates.push(profile);
      }
      return candidates;
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async unAssignedCandidates(
    groupId: string,
    clientId: string
  ): Promise<IProfile[]> {
    try {
      const assignedCandidateId = [];
      const clientsAssignedCandidateId = [];
      const candidateAssigned = await GroupCandidates.find({
        group: groupId,
      });
      for (const assigned of candidateAssigned) {
        assignedCandidateId.push(assigned.candidate);
      }
      const clientAssignedCandidatess = await IClientUsers.find({
        client_profile: clientId,
      });
      for (const assigned of clientAssignedCandidatess) {
        clientsAssignedCandidateId.push(assigned.profile);
      }
      return await Profile.find({
        $and: [
          { _id: { $nin: assignedCandidateId } },
          { _id: { $in: clientsAssignedCandidateId } },
        ],
      });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async create(body: CreateQuery<ICandidateGroup>): Promise<ICandidateGroup> {
    try {
      return await CandidateGroup.create(body);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async update(body: any, id: string): Promise<ICandidateGroup> {
    try {
      return await CandidateGroup.findByIdAndUpdate(id, body, { new: true });
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteById(id: string): Promise<ICandidateGroup> {
    try {
      return await CandidateGroup.findByIdAndDelete(id);
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async deleteAll(): Promise<
    { ok?: number; n?: number } & { deletedCount?: number }
  > {
    try {
      return await CandidateGroup.deleteMany({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }

  async count(): Promise<number> {
    try {
      return await CandidateGroup.countDocuments({});
    } catch (error) {
      if (error) {
        L.error('Error ', error);
        return error.message;
      }
    }
  }
}

export default new CandidateGroupService();
