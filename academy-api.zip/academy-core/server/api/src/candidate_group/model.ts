import mongoose, { Schema, Document } from 'mongoose';

export interface ICandidateGroup extends Document {
  name: 'string';
  description: 'string';
  total_candidates?: number;
}

const CandidateGroupSchema: Schema = new Schema({
  name: {
    type: 'String',
    require: true,
  },
  total_candidates: {
    type: 'Number',
    require: false,
  },
  description: {
    type: 'String',
    require: false,
  },
  client: {
    ref: 'Profile',
    type: 'ObjectId',
  },
});

export default mongoose.model<ICandidateGroup>(
  'CandidateGroup',
  CandidateGroupSchema
);
