<template>
  <div v-if="chapter" class="chapter-details">
    <div class="title">{{chapter.title}}</div>
    <div class="content" v-html="chapter.content"></div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

import chapterService from '../../../services/chapter'

export default defineComponent({
  setup () {
    const route = useRoute()
    const chapter = ref<{ _id: string; title: string; content: string; order: number; course: string }>()
    const courseId = ref<string>(route.params.courseId as string)
    const chapterId = ref<string>(route.params.chapterId as string)
    const getChapter = async (id) => {
      const responce = await chapterService.getChapterDetails(id)
      chapter.value = responce.data
    }
    onMounted(() => {
      getChapter(chapterId.value)
    })
    return {
      chapter,
      courseId,
      chapterId,
      getChapter
    }
  }
})
</script>
<style lang="scss">
.chapter-details {
  .title {
    font-family: "TT Norms Pro Medium";
    font-size: 20px;
  }
  .content {
    margin-top: 10px;
  }
}

</style>
