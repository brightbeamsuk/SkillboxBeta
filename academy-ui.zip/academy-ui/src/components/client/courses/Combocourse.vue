<template>
  <a-row class="combo-lists">
    <div class="body">
      <a-row class="filter">
        <div class="title">Combo Course</div>
        <a-input-search v-model:value="searchString" placeholder="Search here ..." @search="onSearch"/>
      </a-row>
      <div class="users">
        <a-table :row-selection="rowSelection" :columns="columns" :data-source="courses" class="ant-table-striped"
          :rowClassName="(record, index) => (index % 2 === 1 ? 'table-striped' : null)"
          :pagination="{
            defaultPageSize: 10,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '30', '40', '50'],
          }"
          rowKey="_id"
        >
          <template #price="{ text: price }">
            <span>
              <a-tag color="green">£ {{ price }} </a-tag>
            </span>
          </template>
        </a-table>
      </div>
    </div>
  </a-row>
</template>

<script lang="ts">
import { defineComponent, ref, computed, unref, onMounted } from 'vue'
import { ColumnProps } from 'ant-design-vue/es/table/interface'
import { notification } from 'ant-design-vue'

import ICourse from '../../../interface/course'

import courseService from '../../../services/course'
import commonServices from '../../../services/common'
import searchService from '../../../services/filter'

type Key = ColumnProps['key'];
export default defineComponent({
  components: {},
  props: ['clientId'],
  setup (props) {
    const columns = [
      {
        title: 'Courses',
        dataIndex: 'title'
        // onFilter: (value, record) => record.title.indexOf(value) === 0,
        // sorter: (a, b) => a.title.length - b.title.length,
        // sortDirections: ['descend', 'ascend']
      },
      {
        title: 'Price',
        dataIndex: 'price'
        // onFilter: (value, record) => record.price.indexOf(value) === 0,
        // sorter: (a, b) => a.price.length - b.price.length,
        // sortDirections: ['descend', 'ascend'],
        // slots: { customRender: 'price' }
      },
      {
        title: 'Total Credits',
        dataIndex: 'cpd_points'
        // onFilter: (value, record) => record.cpd_points.indexOf(value) === 0,
        // sorter: (a, b) => a.cpd_points.length - b.cpd_points.length,
        // sortDirections: ['descend', 'ascend'],
        // align: 'center'
      },
      {
        title: 'Current Balance',
        dataIndex: 'cpd_bal_points'
        // onFilter: (value, record) => record.cpd_bal_points.indexOf(value) === 0,
        // sorter: (a, b) => a.cpd_bal_points.length - b.cpd_bal_points.length,
        // sortDirections: ['descend', 'ascend'],
        // align: 'center'
      }
    ]
    const courses = ref<Array<ICourse>>([])
    const courseData = ref<Array<ICourse>>([])
    const searchString = ref<string>('')
    const onSearch = async (searchValue: string) => {
      courses.value = searchService.search(courseData.value, searchValue)
    }
    const notify = async (message: string, description: string, type: string) => {
      notification[type]({ message, description })
    }
    const getCourse = async () => {
      const profile = commonServices.getCurrentProfile()
      const clientId = (props.clientId ? props.clientId : profile._id)
      const responce = await courseService.getClientCoursesByType(clientId, 'Group')
      courses.value = responce.data
      courseData.value = responce.data
    }
    // select table rows checkbox
    const selectedRowKeys = ref<Key[]>([])
    const onSelectChange = (changableRowKeys: Key[]) => {
      console.log('selectedRowKeys changed: ', changableRowKeys)
      selectedRowKeys.value = changableRowKeys
    }
    const rowSelection = computed(() => {
      return {
        selectedRowKeys: unref(selectedRowKeys),
        onChange: onSelectChange,
        hideDefaultSelections: true,
        selections: [
          {
            key: 'all-data',
            text: 'Select All Data',
            onSelect: (changableRowKeys: Key[]) => {
              let newSelectedRowKeys = []
              newSelectedRowKeys = changableRowKeys
              selectedRowKeys.value = newSelectedRowKeys
            }
          },
          {
            key: 'odd',
            text: 'Select Odd Row',
            onSelect: (changableRowKeys: Key[]) => {
              let newSelectedRowKeys = []
              newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                if (index % 2 !== 0) {
                  return false
                }
                return true
              })
              selectedRowKeys.value = newSelectedRowKeys
            }
          },
          {
            key: 'even',
            text: 'Select Even Row',
            onSelect: (changableRowKeys: Key[]) => {
              let newSelectedRowKeys = []
              newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                if (index % 2 !== 0) {
                  return true
                }
                return false
              })
              selectedRowKeys.value = newSelectedRowKeys
            }
          }
        ]
      }
    })
    onMounted(() => {
      getCourse()
    })
    return {
      columns,
      onSearch,
      searchString,
      selectedRowKeys,
      rowSelection,
      notify,
      courses
    }
  }
})
</script>

<style lang="scss">
.combo-lists {
  .body {
    background: #ffffff;
    min-height: 200px;
    box-shadow: 0px 5px 10px #00000003;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    padding: 15px;
    width: 100%;
    .title {
      color: #707070;
      float: left;
      font-size: 20px;
      text-transform: capitalize;
      font-family: "TT Norms Pro Medium";
    }
    .filter {
      display: flex;
      justify-content: space-between;
      margin: 15px 0 0 0;
      .noofentries {
        display: flex;
        align-items: center;
        .ant-select {
          margin: 0 5px;
        }
      }
      .ant-input-affix-wrapper {
        width: 200px;
      }
      .ant-select,
      .ant-btn {
        float: left;
      }
      .ant-btn {
        background: #38B6FF;
        border-color: #38B6FF;
        border-radius: 20px;
        font-family: "TT Norms Pro Medium";
      }
    }
    .users {
      margin-top: 20px;
      font-family: "TT Norms Pro Medium";
      .ant-table {
        color: #646464;
        .ant-table-thead {
          tr {
            th {
              background: #E6E6E6;
              color: #646464;
              &:first-child {
                border-top-left-radius: 4px;
                border-bottom-left-radius: 4px;
              }
              &:last-child {
                border-top-right-radius: 4px;
                border-bottom-right-radius: 4px;
              }
            }
          }
        }
        .ant-table-tbody {
          tr {
            td {
              border-bottom:none;
              &:nth-child(2){
                color: #38B6FF;
              }
            }
          }
        }
      }
      .ant-pagination {
        .ant-pagination-options {
          // display: none;
        }
        .ant-pagination-prev .ant-pagination-item-link,
        .ant-pagination-next .ant-pagination-item-link {
          border-radius: 50%;
          background-color: #ededed;
          border: none;
        }
        .ant-pagination-item {
          background-color: #ededed;
          margin-right: 0px;
          border: none;
          font-family: "TT Norms Pro Regular";
        }
        li:nth-child(2) {
          border-top-left-radius: 20px;
          border-bottom-left-radius: 20px;
        }
        li:nth-last-child(3n) {
          border-top-right-radius: 20px;
          border-bottom-right-radius: 20px;
        }
        .ant-pagination-next {
          margin-left: 8px;
        }
        .ant-pagination-item-active {
          background-color: #ededed;
          a {
            background: #6f64f8;
            color: #fff;
            border-radius: 50%;
          }
        }
      }
      .totalentries {
        font-family: "TT Norms Pro Regular";
        text-align: left;
        margin: -40px 0 0 0;
        color: #646464;
        p {
          margin: 0;
        }
      }
    }
  }
}

</style>
<style scoped>
.ant-table-striped :deep(.table-striped) {
  background-color: #F7FAFC;
}
</style>
