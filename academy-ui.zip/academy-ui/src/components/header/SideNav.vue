<template>
  <div class="main-menu">
    <a-button
      type="primary"
      style="margin-bottom: 16px"
      @click="toggleCollapsed"
    >
      <MenuUnfoldOutlined v-if="collapsed" />
      <MenuFoldOutlined v-else />
    </a-button>
    <a-menu
      mode="inline"
      theme="light"
      :inline-collapsed="collapsed"
      :default-selected-keys="['1']"
      :default-open-keys="['2']"
    >
      <a-menu-item key="1">
        <img src="../../assets/images/home.svg" />
        <span class="menu-title">
          <router-link to="/dashboard">Dashboard</router-link>
        </span>
      </a-menu-item>
      <a-menu-item key="2">
        <img src="../../assets/images/category.png" />
        <span class="menu-title">
          <router-link to="/category">Categories</router-link>
        </span>
      </a-menu-item>
      <a-menu-item key="3">
        <img src="../../assets/images/course.png" />
        <span class="menu-title">
          <router-link to="/course">Courses</router-link>
        </span>
      </a-menu-item>
      <a-menu-item key="4">
        <img src="../../assets/images/users.png" />
        <span class="menu-title">
          <router-link to="/users">User Management</router-link>
        </span>
      </a-menu-item>
      <a-menu-item key="5">
        <img src="../../assets/images/payment.png" />
        <span class="menu-title">
          <router-link to="/subscriptions">Manage Payment</router-link>
        </span>
      </a-menu-item>
      <a-menu-item key="6">
        <img src="../../assets/images/client.png" />
        <span class="menu-title">
          <router-link to="/clients">Client</router-link>
        </span>
      </a-menu-item>
      <a-sub-menu key="7">
        <span class="menu-title">
          <img src="../../assets/images/settings.png" />
          <span class="menu-title">Settings</span>
        </span>
        <a-menu-item key="8">
          <span class="menu-title">
            <router-link to="#">Combo List</router-link>
          </span>
        </a-menu-item>
        <a-menu-item key="9">
          <span class="menu-title">
            <router-link to="/keys">Payment (Key)</router-link>
          </span>
        </a-menu-item>
        <a-menu-item key="10">
          <span class="menu-title">
            <router-link to="/sys-settings">System Settings</router-link>
          </span>
        </a-menu-item>
      </a-sub-menu>
    </a-menu>
  </div>
</template>

<script lang="ts">
// import { bus } from '../../bus'
import { defineComponent, reactive, toRefs, watch } from 'vue'
import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons-vue'

export default defineComponent({
  setup () {
    const state = reactive({
      collapsed: false,
      selectedKeys: ['1'],
      openKeys: ['1'],
      preOpenKeys: ['1']
    })
    watch(
      () => state.openKeys,
      (val, oldVal) => {
        state.preOpenKeys = oldVal
      }
    )
    const toggleCollapsed = () => {
      state.collapsed = !state.collapsed
      state.openKeys = state.collapsed ? [] : state.preOpenKeys
    }
    return {
      ...toRefs(state),
      toggleCollapsed
    }
  },
  components: {
    MenuFoldOutlined,
    MenuUnfoldOutlined
  }
})
</script>

<style lang="scss">
.main-menu {
  .ant-btn {
    margin-bottom: 16px;
    box-shadow: none;
    background-color: transparent;
    border-color: transparent;
    color: #656565;
    font-size: 20px;
    float: left;
    margin-left: 10px;
  }
  .ant-btn:hover,
  .ant-btn:focus {
    background-color: transparent;
    border-color: transparent;
    color: #656565;
  }
  .ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected {
    background: #f7fafc 0% 0% no-repeat padding-box;
  }
  .ant-menu {
    .ant-menu-item,
    .ant-menu-submenu {
      text-align: left;
      img {
        width: 15px;
        margin-right: 10px;
      }
      .menu-title {
        font-family: "TT Norms Pro Regular";
        a {
          color: #707070;
        }
        .router-link-active {
          color: #38B6FF;
          font-family: "TT Norms Pro Medium";
        }
      }
    }
  }
}
</style>
