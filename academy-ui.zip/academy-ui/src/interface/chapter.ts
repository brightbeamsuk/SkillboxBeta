export default interface Chapter {
  _id?: string;
  title: string;
  content: string;
  order: number;
  course: string;
  quizzes: [];
  index?: number;
  read?: boolean;
}
