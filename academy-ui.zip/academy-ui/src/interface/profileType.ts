export default interface CourseFormState {
  _id?: string;
  name: string;
  slug: string;
}
