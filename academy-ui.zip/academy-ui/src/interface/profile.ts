export default interface Profile {
  _id?: string;
  user_id?: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  profile_image: string;
  client_name?: string;
  client_logo?: string;
  certificate_access: boolean;
  created_by: string;
  is_active: boolean;
  payment_type?: string;
  profile_type: string;
  status: string;
  send_login?: boolean;
  group?: string;
  password?: string;
  address?: string;
  subscription?: any;
  address_details?: {
    _id?: string;
    address1?: string;
    address2?: string;
    city?: string;
    postal_code?: string;
    location?: any;
    country?: string;
  };
}
