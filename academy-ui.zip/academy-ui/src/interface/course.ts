export default interface CourseFormState {
  _id?: string;
  title: string;
  category: string;
  description: string;
  price: number;
  discount: number;
  provider: string;
  url: string;
  image: string;
  type: string;
  parent_id: string;
  published: boolean;
  cpd_bal_points?: number;
  cpd_points?: number;
  validity?: number;
  assessor?: string;
}
