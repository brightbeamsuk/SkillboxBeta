<template>
  <div class="main">
    <div class="payment-sample content-body">
      <a-breadcrumb>
        <a-breadcrumb-item>
          <HomeOutlined />
        </a-breadcrumb-item>
        <a-breadcrumb-item>
          Sample Payment
        </a-breadcrumb-item>
      </a-breadcrumb>
      <a-row class="body">
        <a-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="payment-type">
          <div class="header">Stripe Payment</div>
          <a-form ref="stripePaymentFormRef" id="payment-form">
            <div class="form-row">
              <a-form-item name="amount">
                <a-input-number :min="1" :max="100000" size="large" v-model:value="stripeForm.amount" style="width: 100%" />
              </a-form-item>
              <div id="card-element">
                <!-- A Stripe Element will be inserted here. -->
              </div>
              <!-- Used to display Element errors. -->
              <div id="card-errors" role="alert"></div>
            </div>

            <button @click="generateStripeSecret">Pay</button>
          </a-form>
          <div class="error" v-if="errorMessage">
            Your transaction has been failed due to {{errorMessage}}
          </div>
          <div class="transaction-success" v-if="transactionSuccess">
            Your transaction has been completed successfully
          </div>
          <div class="loading" v-if="loading">Please wait... Don't close or reload the page.</div>
        </a-col>
        <a-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="payment-type">
          <div class="header">Paypal Payment</div>
          <a-form ref="paypalPaymentFormRef" id="payment-form">
            <div class="form-row">
              <a-form-item name="amount">
                <a-input-number :min="1" :max="100000" size="large" v-model:value="paypalForm.amount" style="width: 100%" />
              </a-form-item>
            </div>
          </a-form>
          <div id="paypal-button-container"></div>
        </a-col>
      </a-row>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, reactive, UnwrapRef } from 'vue'
import { HomeOutlined } from '@ant-design/icons-vue'
import { notification } from 'ant-design-vue'

import keyService from '../services/key'
import commonServices from '../services/common'

declare const Stripe
declare const paypal
interface PaymentIntent {
  amount: number;
  currency: string;
}
export default defineComponent({
  name: 'Dashboard',
  components: {
    HomeOutlined
  },
  setup () {
    const loading = ref<boolean>(false)
    const stripePaymentFormRef = ref()
    const paypalPaymentFormRef = ref()
    const card = ref()
    const paymentKeys = ref()
    const errorMessage = ref<string>('')
    const transactionSuccess = ref<boolean>(false)
    const stripe = ref()
    const elements = ref()
    const notify = async (message: string, description: string, type: string) => {
      notification[type]({
        message,
        description
      })
    }
    const stripeForm: UnwrapRef<PaymentIntent> = reactive({
      amount: 0,
      currency: 'GBP'
    })
    const paypalForm: UnwrapRef<PaymentIntent> = reactive({
      amount: 0,
      currency: 'GBP'
    })
    const style = {
      base: {
        fontSize: '16px',
        color: '#32325d'
      }
    }
    const configurePaypal = async () => {
      paypal.Buttons({
        style: {
          layout: 'vertical',
          color: 'blue',
          shape: 'rect',
          label: 'paypal'
        },
        createOrder: function (data, actions) {
          // This function sets up the details of the transaction, including the amount and line item details.
          return actions.order.create({
            purchase_units: [{
              amount: {
                currency_code: paypalForm.currency,
                value: paypalForm.amount
              }
            }]
          })
        },
        onApprove: function (data, actions) {
          // This function captures the funds from the transaction.
          return actions.order.capture().then(function (details) {
            // This function shows a transaction success message to your buyer.
            console.log('transaction completed', details)
          })
        },
        onCancel: function (data) {
          console.log('canceled', data)
        }
      }).render('#paypal-button-container')
    }
    const configureStripe = async () => {
      const stripeKey = paymentKeys.value.filter(key => key.type === 'Stripe')
      if (stripeKey.length === 0) errorMessage.value = 'Stripe public key is not configured'
      stripe.value = Stripe(stripeKey[0].key)
      elements.value = stripe.value.elements()
      card.value = elements.value.create('card', { style })
      card.value.mount('#card-element')
    }
    const getGatewaySettings = async () => {
      try {
        const responce = await keyService.getKeys()
        paymentKeys.value = responce.data
        console.log('paymentKeys', paymentKeys.value)
        configureStripe()
      } catch (error) {
        notify('Error', error.data, 'error')
      }
    }
    const generateStripeSecret = async () => {
      try {
        loading.value = true
        transactionSuccess.value = false
        errorMessage.value = ''
        stripeForm.amount = +stripeForm.amount
        const profile = commonServices.getCurrentProfile()
        const responce = await keyService.generateStripeSecretToken(stripeForm)
        if (typeof responce.data === 'string') {
          errorMessage.value = responce.data
          loading.value = false
          return false
        }
        const result = await stripe.value.confirmCardPayment(responce.data.client_secret, {
          payment_method: {
            card: card.value,
            billing_details: {
              name: `${profile.first_name} ${profile.last_name}`,
              email: profile.email
            }
          }
        })
        console.log('result', result)
        loading.value = false
        // Save transaction details to DB
        if (result.error) {
          errorMessage.value = result.error.message
        } else {
          if (result.paymentIntent.status === 'succeeded') {
            transactionSuccess.value = true
          }
        }
      } catch (error) {
        notify('Error', error.data, 'error')
      }
    }
    onMounted(() => {
      getGatewaySettings()
      configurePaypal()
    })
    return {
      loading,
      stripeForm,
      paypalForm,
      stripePaymentFormRef,
      paypalPaymentFormRef,
      generateStripeSecret,
      errorMessage,
      transactionSuccess
    }
  }
})
</script>
<style lang="scss">
.payment-sample{
  .body {
    .payment-type {
      background: #fff;
      padding: 15px;
      border-radius: 10px;
      min-height: 200px;
      .header {
        text-align: left;
        padding: 15px 0;
        font-size: 16px;
        font-weight: bold;
      }
      #card-element {
        border: 1px solid #e3e8ee;
        height: 44px;
        border-radius: 4px;
        padding: 12px;
        margin-bottom: 20px;
      }
      #payment-form {
        .ant-form-item-control-wrapper {
          width: 100%;
        }
        .ant-input-number {
          border: 0;
        }
        .ant-input-number-lg input {
          height: 44px;
          border-radius: 4px;
          border: 1px solid #e3e8ee;
        }
        button {
          background-color: rgb(84, 105, 212);
          color: rgb(255, 255, 255);
          line-height: 28px;
          border-radius: 4px;
          padding: 6px 16px;
          border: 0;
          outline: 0;
          width: 200px;
        }
        .error {
          color: #ff0000;
          font-size: 17px;
          padding: 15px;
        }
        .transaction-success {
          color: #008000;
          font-size: 17px;
          padding: 15px;
        }
      }
    }
  }
}
</style>
